//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "TxtSeriesLabel.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TDataSeriesLabel *DataSeriesLabel;

FILE *fout;
//---------------------------------------------------------------------------
__fastcall TDataSeriesLabel::TDataSeriesLabel(TComponent* Owner)
	: TForm(Owner)
{
}
//-----------------------------------------------------------------------------

__fastcall TDataSeriesLabel::TDataSeriesLabel(FILE *f, TComponent *Owner)
	: TForm(Owner)
{
   fout=f;
}

//------------------------------------------------------------------------------


void __fastcall TDataSeriesLabel::bOKClick(TObject *Sender)
{
   int len=eSeriesLabel->GetTextLen();
   wchar_t *buf = new wchar_t[len+1];
   eSeriesLabel->GetTextBuf(buf,len+1);
   AnsiString as=buf;

   if(len==0)fprintf(fout,"\n");
   else{
       fprintf(fout,"%s\n",as);
   }
   Close();

   delete [] buf;
}
//---------------------------------------------------------------------------

