//---------------------------------------------------------------------------
#include <stdio.h>
#include <vcl.h>
#pragma hdrstop

#include "AmpVsDurPlt.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfAmpvsDurPlt *fAmpvsDurPlt;
FILE *ff;
//---------------------------------------------------------------------------
__fastcall TfAmpvsDurPlt::TfAmpvsDurPlt(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
 __fastcall TfAmpvsDurPlt::TfAmpvsDurPlt(float *pkarr, float *subpkarr, float *widtharr,
										 int arrcnt, FILE *f,TComponent* Owner)
	 :TForm(Owner)
 {
	  ff=f;
	  double xmin=widtharr[0],xmax=widtharr[0],ymin=pkarr[0],ymax=pkarr[0];
	  AnsiString val;

  	  Chart1->Series[0]->Clear();
	  Chart1->LeftAxis->LabelStyle=talValue;
	  Chart1->BottomAxis->LabelStyle=talText;

	  for(int i=0; i<arrcnt; i++){
		 val=FloatToStrF(widtharr[i],ffExponent,1,1);
		 Chart1->Series[0]->AddXY(widtharr[i],pkarr[i],val,clTeeColor);
      }
 }
 //---------------------------------------------------------------------------
void __fastcall TfAmpvsDurPlt::bPrintClick(TObject *Sender)
{
   Chart1->PrintLandscape();

}
//---------------------------------------------------------------------------

void __fastcall TfAmpvsDurPlt::bSaveTofileClick(TObject *Sender)
{
   AnsiString ampdurfile;
   char adfile[1000];

   if(dAmpDurSave->Execute()){
	  ampdurfile=dAmpDurSave->FileName;
	  sprintf(adfile,"%s.wmf",ampdurfile);

	  Chart1->SaveToMetafile(adfile) ;

   }
}
//---------------------------------------------------------------------------

void __fastcall TfAmpvsDurPlt::bExportClick(TObject *Sender)
{
   FILE *fout;
   AnsiString fn;
   char line[1000];

   if(dAmpDurSave->Execute()){
	  fn=dAmpDurSave->FileName;
	  fout=fopen(fn.c_str(),"wt");
	  while(!feof(ff)){
		 fgets(line,1000,ff);
		 fprintf(fout,"%s",line);
	  }
	  fclose(fout);

   }
}
//---------------------------------------------------------------------------

