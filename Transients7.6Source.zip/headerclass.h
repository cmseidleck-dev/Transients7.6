/* Modified header class to correctly ignore comment line(s) and subsequent LF and CR
   Also read in timetag (8 chars following ^H in new format files) for future use
   cms-7/2003
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

class fileheader {
   public:
        int channels;
        double acq;
        int NumFrames;
        bool NewFileFmt;
        double Xinc;   //same for all channels in all frames
        double Yoff[4]; //[1-3] are n/a if channels=1
        double Yinc[4]; //[1-3] are n/a if channels=1
        double Yzero[4]; //[1-3] are n/a if channels=1
   public:
        int GetHeaderInfo(FILE *f, int &digits);
        void ScanForComments(FILE *f,FILE *hdr);
         void ScanForData(FILE *f,FILE *hdr); //for Marty files
};
//-----------------------------------------------------------------------------

int fileheader::GetHeaderInfo(FILE *f, int &digits)
{
   char *token,data[80];
   FILE *hdr;
   bool cmt=false;
   int curvepoints;

   hdr=fopen("header.dat","wt");

   try {
      fgets(data,80,f); //hdr1--contains Data: or channels
      strtok(data,":");
      strtok(NULL,":");
      token=strtok(NULL,"\n");
      channels=atoi(token);  //get channels

      fgets(data,80,f);  //hdr2--get # of curve points here
      strtok(data,":");
      token=strtok(NULL,"\n");
      digits=atoi(token);   
      
      fgets(data,80,f);  //hdr3-- acquisitions,#frames
      strtok(data,":");
      token=strtok(NULL,"#");
      acq=abs(atof(token));
      strtok(NULL,":");
      token=strtok(NULL,"\n");  //number of frames
      NumFrames=atoi(token);

      fgets(data,80,f);  //hdr4  --Xinc
      strtok(data,":");
      token=strtok(NULL,"\n");
      Xinc=atof(token);  //Xinc

      fgets(data,80,f); //hdr5 --Yoff[0..n],n<=4
      strtok(data,":");
      for (int i=0; i<channels; i++) {  //get all Yoff(s) according to #channels
         token=strtok(NULL,":");
         if (token==NULL)Yoff[i]=Yoff[0]; //just use the one for chan0
         else Yoff[i]=atof(token);
      }
      fgets(data,80,f);  //hdr6 --Yinc[0..n],n<=4
      strtok(data,":");
      for (int i=0; i<channels; i++) { //get all Yinc(s) according to #channels
         token=strtok(NULL,":");
         if (token==NULL)Yinc[i]=Yinc[0]; //just use the one for chan0
         else Yinc[i]=atof(token);
      }
      fgets(data,80,f);  //hdr7 --Yzero[0..n],n<=4
      strtok(data,":");

      for (int i=0; i<channels; i++) {
         token=strtok(NULL,":");
         if (token==NULL)Yzero[i]=Yzero[0];  //just use the one for chan0
         else Yzero[i]=atof(token);
      }
      
      fprintf(hdr,"chans=%d\n cpoints=%d\n acq=%le\n frames=%d\n Xinc=%le\n",channels,digits,
                                                             acq,NumFrames,Xinc);
      for (int i=0; i<channels; i++)fprintf(hdr,"Yoff%d=%lf, ",i,Yoff[i]);
      fprintf(hdr,"\n");
      for (int i=0; i<channels; i++)fprintf(hdr,"Yinc%d=%lf, ",i,Yinc[i]);
      fprintf(hdr,"\n");
      for (int i=0; i<channels; i++)fprintf(hdr,"Yzero%d=%lf, ",i,Yzero[i]);
      fprintf(hdr,"\n");
      }catch(...) {
         return(-1);
      }

      ScanForData(f,hdr);
      fclose(hdr);
 }
 //---------------------------------------------------------------------------
 void fileheader::ScanForData(FILE *f,FILE *hdr)
 {
    char ch;
    bool DataFound=false;

    while ((!DataFound)&&(!feof(f))) {
       ch=fgetc(f);
       switch (ch) {
         case '#' : if (!feof(f))ch=fgetc(f);
                    if (ch=='3') {
                       NewFileFmt=false;
                       DataFound=true;
                       fprintf(hdr,"NewFmtFlag=false\n");
                    }
                    break;
         case '^' : if (!feof(f))ch=fgetc(f);
                     if (ch=='H') {
                        NewFileFmt=true;
                        DataFound=true;
                        fprintf(hdr,"NewFmtFlag=true\n");
                     }
                    
                     break;
         default : break;
       }
    }
  }
 //---------------------------------------------------------------------------

 void fileheader::ScanForComments(FILE *f,FILE *hdr)
 {
      char ch;
      bool endCmt=false;

      while ( (!feof(f))&&( (ch!=0x2f)|| (ch!='^') ) )ch=fgetc(f);

      if (ch==0x2f) {     // '/'
         if (!feof(f))ch=getc(f);
         if (ch=='*') {
            while((!feof(f))&& (!endCmt)) {
               ch=fgetc(f);
               if (ch=='*') {
                  if (!feof(f))ch=fgetc(f);
                  if (ch==0x2f) {    // '/'
                     endCmt=true;
                     fprintf(hdr,"End Cmt found\n");
                  }
               }
            }
            if (!feof(f))ch=fgetc(f); //get the next character
         }
         while ((!feof(f))&& ((ch== 0x0d)||(ch==0x0a))) {
            fprintf(hdr,"ch= %x\n",(int)ch);
            ch=fgetc(f);        //gotta get rid of CR and LF (0x0d,0x0a) after cmt
         }
      }
      if (ch=='^') {    //check for new file format (^H<timetag>(total 10 chars))
         if (!feof(f))ch=fgetc(f);
         if (ch=='H') {
            NewFileFmt=true;
            fprintf(hdr,"NewFmtFlag=true\n");
         }
      }
      else {
         NewFileFmt=false;
         fprintf(hdr,"NewFmtFlag=false\n");
      }


 }
 //---------------------------------------------------------------------------
