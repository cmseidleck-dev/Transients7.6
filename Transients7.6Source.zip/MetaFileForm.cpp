//---------------------------------------------------------------------------

#include <vcl.h>
#include <stdio.h>
#pragma hdrstop

#include "MetaFileForm.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TTMetaFileForm *TMetaFileForm;
TDBChart *cptr;
//---------------------------------------------------------------------------
__fastcall TTMetaFileForm::TTMetaFileForm(TComponent* Owner)
        : TForm(Owner)
{

}
//---------------------------------------------------------------------------
__fastcall TTMetaFileForm::TTMetaFileForm(TDBChart *DBChart1, TComponent* Owner)
        : TForm(Owner)
{
   cptr=DBChart1;
}
//---------------------------------------------------------------------------

void __fastcall TTMetaFileForm::bbOKClick(TObject *Sender)
{
   char savename[800];
   AnsiString f;

   int sz=efilename->GetTextLen();
   if (sz<1) {
      Application->MessageBox(L"Enter File Name",L"USER ERROR",MB_OK);
      efilename->SetFocus();
   }
   else {
      sz++;
	  wchar_t *buf=new wchar_t[sz];
	  efilename->GetTextBuf(buf,sz);
	  f=buf;
      sprintf(savename,"%s.wmf",f);
      cptr->SaveToMetafile(savename);
      delete buf;
   }
}
//---------------------------------------------------------------------------

