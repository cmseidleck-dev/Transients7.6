//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "FSaveForm.h"
#include <stdio.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

TFileSaveForm *FileSaveForm;
double *XINC;
float *CURVE1;
float *SUBCURVE;
float *MMEAN;
int NUMCURVEPOINTS;

//---------------------------------------------------------------------------
__fastcall TFileSaveForm::TFileSaveForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
__fastcall TFileSaveForm::TFileSaveForm(double *xinc, float *curve1, float *subcurve, float *mmean, TComponent* Owner,int NumCurvePoints)
        :TForm(Owner)
{
   XINC=xinc;
   CURVE1=curve1;
   SUBCURVE=subcurve;
   MMEAN=mmean;
   NUMCURVEPOINTS=NumCurvePoints;
}

//----------------------------------------------------------------------------
void __fastcall TFileSaveForm::bbOKClick(TObject *Sender)
{
   int sz=filename->GetTextLen();
   AnsiString str;
   if (sz<1) {
      Application->MessageBox(L"Enter File Name",L"USER ERROR",MB_OK);
      filename->SetFocus();
   }
   else {
      sz++;
	  wchar_t *buf=new wchar_t[sz]; //char *buf=new char[sz];
	  filename->GetTextBuf(buf,sz);
	  str=buf;
//	  str.sprintf("%s",buf);
      FILE *f;
	  f=fopen(str.c_str(),"wt");
      fprintf(f,"XINC\tCURVE1\tSUBCURVE\tMEAN\n\n");
      for (int i=0; i<NUMCURVEPOINTS; i++)fprintf(f,"%le\t%f\t%f\t%f\n",XINC[i],CURVE1[i],SUBCURVE[i],MMEAN[i]);

      fclose(f);
      delete buf;
   }
}
//---------------------------------------------------------------------------
