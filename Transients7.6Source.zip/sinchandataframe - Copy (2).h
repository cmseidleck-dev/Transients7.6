//gets a single channel of data class for the NRL00Jul HS139,
//NRL00Jul LM139, and the BNL00Mar LM139



class sinchandataFrame {
   private:
      long timetag;
      signed char curve1[MAXPOINTS];
      float fcurve1[MAXPOINTS];
      float Rank[MAXPOINTS];
      float MMean[MAXPOINTS];
      double fxinc[MAXPOINTS];
      float curveMax;
      float subcurveMax;
      double width1;
      double WSTRT;   //value of XINC at strt of width calc
      double WEND;    //value of XINC at end of width calc
      int IDXofPeak;
      int IDXofMeanMax;
      float baseLine;
      bool Deleted;     //whether or not frame will be included in the analysis


   public:

      bool ParseDataArr(int &start, double &mean, double &stddev, double &var, int &stop);
      void GetMeanStdDev(int chan);
      int FindPulseWidthMovAVG(float *fltarr,int wPeak, FILE *f, int chan);
      void FindPeak(int chan);
	  bool FindWidthPos(int & strtPos, int & endPos, int chan);
	  bool FindWidthPosUSER(int & strtPos, int & endPos, int chan);
      bool FindWidthTolerance(int & strtPos, int & endPos, int chan);
	  bool FindWidthTolerance2(int & strtPos, int & endPos, int chan);
      void GetMMean(float *arr);

      void GetStrtEnd(double & strt, double & end);
      void GetHiLoVals(double &hival,double &loval);

      void GetdataFrame(char *arr,long Time);  //(char *arr, int NumCurvePoints, int NumBaseLinePoints,long Time);
      void CalcNewVals(double XINC,double YINC,double YPOS,double YOFF,char *pointArr);
      int BinPeakVals(float *fltarr,FILE *fd1, FILE *tmp, int wPeak);
      int BinIt(float *fltarr, int wPeak);
      void GetFXinc(double *arr);
      void GetFCurve1(float *arr);
      float GetPeakVal(void);
      double GetWidth1Val(void);
      float GetSubPeakVal(void);

      void DeleteFrame(void);
      bool IsDeleted(void);
      long GetTime(void);
      void AssignRank(float rnk, int m);



};

void sinchandataFrame::AssignRank(float rnk, int m)
{   Rank[m]=rnk;   }

//------------------------------------------------------------------------------
void sinchandataFrame::GetStrtEnd(double & strt, double & end)
{
    strt=WSTRT;
    end=WEND;
}

//------------------------------------------------------------------------------
long sinchandataFrame::GetTime(void)
{  return(timetag); }
//------------------------------------------------------------------------------
void sinchandataFrame::DeleteFrame(void)
{  Deleted=true;   }

//------------------------------------------------------------------------------
bool sinchandataFrame::IsDeleted(void)
{   return(Deleted);   }
//------------------------------------------------------------------------------
double sinchandataFrame::GetWidth1Val(void)
{  return(width1); }


//------------------------------------------------------------------------------

float sinchandataFrame::GetPeakVal(void)
{  return(curveMax);   }

//------------------------------------------------------------------------------

float sinchandataFrame::GetSubPeakVal(void)
{   return (subcurveMax);   }
//------------------------------------------------------------------------------
void sinchandataFrame::GetFXinc(double *arr)
{ for (int i=0; i<NumOfCurvePoints; i++)arr[i]=fxinc[i]; }
//------------------------------------------------------------------------------
void sinchandataFrame::GetFCurve1(float *arr)
{ for (int i=0; i<NumOfCurvePoints; i++)arr[i]=fcurve1[i]; }
//------------------------------------------------------------------------------
void sinchandataFrame::GetMMean(float *arr)
{   for (int i=0; i<NumOfCurvePoints; i++)arr[i]=MMean[i];   }
//-----------------------------------------------------------------------------

void sinchandataFrame::GetdataFrame(char *arr,long Time)
{                                     //(char *arr, int NumCurvePoints,int NumBaselinePoints, long Time)
//  NumOfCurvePoints=NumCurvePoints;
//   if ((NumBaselinePoints>0)&&(NumBaselinePoints<MAXPOINTS))NumBaseLinePoints=NumBaselinePoints;
//   else NumBaseLinePoints=NumOfCurvePoints;

   for (int i=0; i<NumOfCurvePoints; i++)curve1[i]=arr[i];
   timetag=Time;
}

//------------------------------------------------------------------------------
void sinchandataFrame::CalcNewVals(double XINC,double YINC,double YPOS,double YOFF,char *pointArr)
{

   signed char *c1;
   c1=(signed char *)&pointArr[0];

   for (int i=0; i<NumOfCurvePoints; i++) {            //changed*****
      fcurve1[i]=c1[i];
      fxinc[i]=XINC*i;
      fcurve1[i]=(fcurve1[i]-YPOS)*YINC+YOFF;
      MMean[i]=0;
   }

   Deleted=false;          //initialize

}

//------------------------------------------------------------------------------
int sinchandataFrame::BinPeakVals(float *fltarr, FILE *fd1, FILE *tmp, int wPeak)
{
   float PeakVal;
   float inc;
   float binmin=fltarr[0];
   float binmax=fltarr[1];
   int numBins=(int)fltarr[2];

   PeakVal=curveMax;

   inc=(binmax-binmin)/numBins;

   if (PeakVal<=binmin)return(0);   //load <binmin into first endpoint

   for (int i=0; i<numBins; i++) {
      if ((PeakVal>=binmin)&&(PeakVal<=(binmin+=inc)))return(i);
   }
   if (PeakVal>binmin)return(numBins-1);  //load >binmax into sec endpoint
}


//------------------------------------------------------------------------------
bool sinchandataFrame::ParseDataArr(int &start, double &mean, double &stddev, double &var, int &stop)
{
   bool end=false;
   int i;

   stop=(NumBaselinePoints)+start;      //loop iterates to stop-1

   if (stop>NumOfCurvePoints)stop=NumOfCurvePoints;

   if (start==NumOfCurvePoints-1)end=true;
   else end=false;
   
   int subsetIDX=0;
   for (i=start; i<stop; i++){
      subsetfcurve1[subsetIDX]=fcurve1[i];
      subsetIDX++;
   }

   if (subsetIDX<=1)subsetIDX=2;   //so stat routines don't blow

   try {
      mean=Mean(subsetfcurve1,subsetIDX-1);
      var=Variance(subsetfcurve1,subsetIDX-1);
      stddev=StdDev(subsetfcurve1,subsetIDX-1);

   }catch(...)
   {
      end=true;
	  Application->MessageBox(L"STAT rountines blew",L"APP ERR",MB_OK);
   }

   return(end);      //return loop termination flag
}
//------------------------------------------------------------------------------

void  sinchandataFrame::FindPeak(int chan)       //sets subcurveMax
{
   double Mean,Var,stddev,MeanLast,VarLast,lastVal;
   bool done=false;
   int arrStart=0,stop=NumBaselinePoints-1,IDXofPeak1;

   lastVal=STDDEV[chan];
   MeanLast=MEAN[chan];
   VarLast=VARIANCE[chan];

   MMean[0]=MEAN[chan];

   arrStart=1;

   IDXofPeak=-1;

   while(!done){
      done=ParseDataArr(arrStart,Mean,stddev,Var,stop);
      if ( fabs(Mean-MEAN[chan]) > fabs(MeanLast-MEAN[chan])){        //changed

        float curve1max=fcurve1[arrStart];

        for (int idx=arrStart+1; idx<arrStart+1+(NumBaselinePoints-1); idx++) {
           if (idx>NumOfCurvePoints-PosFromCurveEnd) ;               //cant find max mean this close to curve end   new
           else {                                                           //new

              if( (fabs(fcurve1[idx]-MEAN[chan])) >  (fabs(curve1max-MEAN[chan])) ){     //new
                 IDXofPeak=idx;                                            //new
                 MeanLast=Mean;                                           //new
                 curve1max=fcurve1[idx];
				 IDXofMeanMax=arrStart;                          //new
              }
           }                                                          //new
        }                                                            //new
      }
	  MMean[arrStart]=Mean;
      arrStart++;

   }

   if (IDXofPeak>-1){

	  curveMax=fcurve1[IDXofPeak];
	  subcurveMax=curveMax-MEAN[chan];
   }

}
//------------------------------------------------------------------------------
void sinchandataFrame::GetMeanStdDev(int chan) //calcs mean and std dev from NumOfCurvePoints of srecnum 0->chan0 ->chan1 2->chan2 3->chan3

{

   for (int i=0; i<NumOfCurvePoints; i++)subsetfcurve1[i]=fcurve1[i];

   STDDEV[chan]=0;
   MEAN[chan]=0;
   VARIANCE[chan]=0;
   LOVAL[chan]=0;
   HIVAL[chan]=0;
						  //calculated on reference frame for ea channel w no transients in it
   STDDEV[chan]=StdDev(subsetfcurve1,NumOfCurvePoints-1);
   MEAN[chan]=Mean(subsetfcurve1,NumOfCurvePoints-1);
   VARIANCE[chan]=Variance(subsetfcurve1,NumOfCurvePoints-1);

   if (STDDEV[chan]==0.0){
      STDDEV[chan]=0.01*MEAN[chan];
   }

   if (USERTolerance){
      HIVAL[chan]=MEAN[chan]+(USERSTD*MEAN[chan]);
	  LOVAL[chan]=MEAN[chan]-(USERSTD*MEAN[chan]);
   }
   else if (USERSTDDEV){                                  //std dev
      HIVAL[chan]=MEAN[chan]+(USERSTD*STDDEV[chan]);
      LOVAL[chan]=MEAN[chan]-(USERSTD*STDDEV[chan]);
   }
   else if (USERDEF) {
	  HIVAL[chan]=uVAL;    //for plot display
	  LOVAL[chan]=uVAL;
   }
//major cheat for Michael *****  REMOVE ****

 /*  STDDEV[chan]=0.0207487337;    values from similar setup having a proper 0 frame
   MEAN[chan]=65.29117553939;
   HIVAL[chan]=65.31192427;
   LOVAL[chan]=65.277042680569;  */

}
//------------------------------------------------------------------------------
bool sinchandataFrame::FindWidthPosUSER(int & strtPos, int & endPos, int chan)    //start and end postions for width calculation
{
   strtPos=-1;
   endPos=-1;

   if (IDXofPeak==-1)return false;         //no width can be calculated, no peak was found


   for (int i=IDXofPeak; i>0; i--) {       //from pk backwards find first <uVAL
	  if (fcurve1[i] < uVAL) {     //this should be the last place the mean is out of the range post peak
		 strtPos=i;
		 break;
	  }
   }
   for (int i=IDXofPeak; i<NumOfCurvePoints; i++) {

	  if (fcurve1[i] < uVAL){   //from pk forwards find first <uVAL
		 endPos=i;
		 break;
	  }
   }
   if ( (strtPos!=-1)&&(endPos!=-1))return(true);
   else return(false);

}
//------------------------------------------------------------------------------


bool sinchandataFrame::FindWidthPos(int & strtPos, int & endPos, int chan)    //start and end postions for width calculation
{
   strtPos=-1;
   endPos=-1;

   if (IDXofPeak==-1)return false;         //no width can be calculated, no peak was found

   if( (MMean[NumOfCurvePoints-10]< LOVAL[chan]) || (MMean[NumOfCurvePoints-10] > HIVAL[chan]) )return(false);  //curve never returns after Peak no width

   for (int i=NumOfCurvePoints-30; i>IDXofMeanMax; i--) {       //find end position first
	  if ( (MMean[i] < LOVAL[chan])||(MMean[i] > HIVAL[chan]) ){     //this should be the last place the mean is out of the range post peak
		 endPos=i;
		 break;
	  }
   }
   for (int i=0; i<IDXofMeanMax; i++) {

	  if ( (MMean[i] < LOVAL[chan])||(MMean[i] > HIVAL[chan]) ) {   //from beginning to first time mean is out of bounds
		 strtPos=i;
		 break;
	  }
   }
   if ( (strtPos!=-1)&&(endPos!=-1))return(true);
   else return(false);

}
//------------------------------------------------------------------------------

bool sinchandataFrame::FindWidthTolerance2(int & strtPos, int & endPos, int chan)   //start and end postions for width calculation
{
   strtPos=-1;
   endPos=-1;

   if (IDXofPeak==-1)return false;     //no width can be calculated, no peak was found
      if ( (fcurve1[NumOfCurvePoints-2] < LOVAL[chan]) || (fcurve1[NumOfCurvePoints-2] > HIVAL[chan]) )
         if   ( (fcurve1[NumOfCurvePoints-3] < LOVAL[chan]) || (fcurve1[NumOfCurvePoints-3] > HIVAL[chan]) )return(false);
         
   if ( (fcurve1[NumOfCurvePoints-1] < LOVAL[chan]) || (fcurve1[NumOfCurvePoints-1] > HIVAL[chan]) )  //curve never returns after Peak no width

   for (int i=NumOfCurvePoints-1; i>IDXofPeak; i--) {   //find end position first
      if ( (fcurve1[i] < LOVAL[chan])||(fcurve1[i] > HIVAL[chan]) ){  //this should be the last place fcurve1 is out of the range post peak
         endPos=i;
         break;
      }
   }
   for (int i=0; i<IDXofPeak; i++) {

      if ( (fcurve1[i] < LOVAL[chan])||(fcurve1[i] > HIVAL[chan]) ) { //from beginning to first time fcurve1 is out of bounds
         strtPos=i;
         break;
      }
   }
   if ( (strtPos!=-1)&&(endPos!=-1))return(true);
   else return(false);
}
//------------------------------------------------------------------------------
bool sinchandataFrame::FindWidthTolerance(int & strtPos, int & endPos, int chan)  //3 consecutive points outside bounds
{                                                                                 //use this one for really noisy data
   strtPos=-1;
   endPos=-1;

   if (IDXofPeak==-1)return false;

   if ( (fcurve1[NumOfCurvePoints-1] < LOVAL[chan]) || (fcurve1[NumOfCurvePoints-1] > HIVAL[chan]) ) //curve never returns after Peak no width
      if ( (fcurve1[NumOfCurvePoints-2] < LOVAL[chan]) || (fcurve1[NumOfCurvePoints-2] > HIVAL[chan]) )
         if   ( (fcurve1[NumOfCurvePoints-3] < LOVAL[chan]) || (fcurve1[NumOfCurvePoints-3] > HIVAL[chan]) )return(false);

   int i=NumOfCurvePoints-1;

   do{
      if ( (fcurve1[i] < LOVAL[chan])||(fcurve1[i] > HIVAL[chan]) ){
         if ( (fcurve1[i-1] < LOVAL[chan])||(fcurve1[i-1] > HIVAL[chan]) ){
            if ( (fcurve1[i-2] < LOVAL[chan])||(fcurve1[i-2] > HIVAL[chan]) ){

               endPos=i;
               break;
            }
         }
      }
      i--;
   }while (i > IDXofPeak);

   i=0;

   do{
      if ( (fcurve1[i] < LOVAL[chan])||(fcurve1[i] > HIVAL[chan]) ){
         if ( (fcurve1[i+1] < LOVAL[chan])||(fcurve1[i+1] > HIVAL[chan]) ){
            if ( (fcurve1[i+2] < LOVAL[chan])||(fcurve1[i+2] > HIVAL[chan]) ){

               strtPos=i;
               break;
            }
         }
      }
      i++;
   }while (i < IDXofPeak);

   if ( (strtPos!=-1)&&(endPos!=-1))return(true);
   else return(false);
}
//------------------------------------------------------------------------------
int sinchandataFrame::FindPulseWidthMovAVG(float *fltarr,int wPeak, FILE *f, int chan)
{                             //wPeak=1 for first peak, 2 for second peak
   double frsttime,sectime;
   int frstidx,secidx;
   double voltval1=0,voltval2=0;   //these are the points with which to calculate width

   bool Found;
   if (USERTolerance)Found=FindWidthTolerance(frstidx,secidx,chan);
   else if (USERSTDDEV)Found=FindWidthPos(frstidx,secidx,chan);
   else if (USERDEF)Found=FindWidthPosUSER(frstidx,secidx,chan);


   if (Found){
      voltval1=fxinc[frstidx];
      voltval2=fxinc[secidx];
      width1=voltval2-voltval1;
      WSTRT=fxinc[frstidx];
      WEND=fxinc[secidx];
   }
   else {
      width1=0;
      WSTRT=0;
      WEND=0;
   }
   
   return 0;
}

//------------------------------------------------------------------------------
int sinchandataFrame::BinIt(float *fltarr, int wPeak)
{
   float wbinmin=fltarr[3];
   float wbinmax=fltarr[4];
   int wnumbins=(int)fltarr[5];
   float inc;
   double width;

   inc=(wbinmax-wbinmin)/wnumbins;

   width=width1;

   if (width<=wbinmin)return(0);  //load <wbinmin into first endpoint
   for (int i=0; i<wnumbins; i++) {
      if ((width>wbinmin)&&(width<=(wbinmin+=inc)))return(i);
   }
   if (width>wbinmin)return(wnumbins-1); //load >binmax into sec endpoint
}
//------------------------------------------------------------------------------

