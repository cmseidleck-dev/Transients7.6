//---------------------------------------------------------------------------
#ifndef FSaveFormH
#define FSaveFormH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>

//---------------------------------------------------------------------------
class TFileSaveForm : public TForm
{
__published:	// IDE-managed Components
        TEdit *filename;
        TBitBtn *bbOK;
        TBitBtn *bbCancel;
        TLabel *Label1;
        void __fastcall bbOKClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TFileSaveForm(TComponent* Owner);
        virtual __fastcall TFileSaveForm(double *xinc, float *curve1, float *subcurve, float *mmean, TComponent* Owner, int NumCurvePoints);

};
//---------------------------------------------------------------------------
extern PACKAGE TFileSaveForm *FileSaveForm;
//---------------------------------------------------------------------------
#endif
