//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include <tchar.h>
//---------------------------------------------------------------------------





















USEFORM("RayMethod.cpp", Weighted);
USEFORM("transients.cpp", Form1);
USEFORM("MetaFileForm.cpp", TMetaFileForm);
USEFORM("AmpVsDurPlt.cpp", fAmpvsDurPlt);
USEFORM("FSaveForm.cpp", FileSaveForm);
USEFORM("Histogram.cpp", HistogramForm);
USEFORM("TxtSeriesLabel.cpp", DataSeriesLabel);
//---------------------------------------------------------------------------
WINAPI _tWinMain(HINSTANCE, HINSTANCE, LPTSTR, int)
{
	try
	{
		Application->Initialize();
		Application->MainFormOnTaskBar = true;
		Application->CreateForm(__classid(TForm1), &Form1);
		Application->CreateForm(__classid(TWeighted), &Weighted);
		Application->CreateForm(__classid(TFileSaveForm), &FileSaveForm);
		Application->CreateForm(__classid(TTMetaFileForm), &TMetaFileForm);
		Application->CreateForm(__classid(THistogramForm), &HistogramForm);
		Application->CreateForm(__classid(TfAmpvsDurPlt), &fAmpvsDurPlt);
		Application->CreateForm(__classid(TDataSeriesLabel), &DataSeriesLabel);
		Application->Run();
	}
	catch (Exception &exception)
	{
		Application->ShowException(&exception);
	}
	catch (...)
	{
		try
		{
			throw Exception("");
		}
		catch (Exception &exception)
		{
			Application->ShowException(&exception);
		}
	}
	return 0;
}
//---------------------------------------------------------------------------
