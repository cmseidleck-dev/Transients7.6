//---------------------------------------------------------------------------

#ifndef RayMethodH
#define RayMethodH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <VCLTee.Chart.hpp>
#include <VCLTee.DBChart.hpp>
#include <ExtCtrls.hpp>
#include <VCLTee.Series.hpp>
#include <VCLTee.TeEngine.hpp>
#include <VCLTee.TeeProcs.hpp>

//Rank Plot


//---------------------------------------------------------------------------
class TWeighted : public TForm
{
__published:	// IDE-managed Components
        TDBChart *DBChart1;
        TLineSeries *Series1;
        TEdit *Ymin;
        TEdit *Ymax;
        TEdit *Xmin;
        TEdit *Xmax;
        TButton *bChangeRank;
        TLabel *Label1;
        TLabel *Label2;
        TLabel *Label3;
        TLabel *Label4;
        TButton *Button1;
        void __fastcall bChangeRankClick(TObject *Sender);
        void __fastcall Button1Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TWeighted(TComponent* Owner);

        virtual __fastcall TWeighted(char *type,AnsiString fname,int NumOfCurvePoints,float mnpk,float mxpk,
                                     float mnrank,float mxrank,float *pkarr, float *rankarr,
                                     TComponent *Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TWeighted *Weighted;
//---------------------------------------------------------------------------
#endif
