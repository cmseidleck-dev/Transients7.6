//---------------------------------------------------------------------------

#ifndef transientsH
#define transientsH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <FileCtrl.hpp>
#include <VCLTee.Chart.hpp>
#include <VCLTee.DBChart.hpp>
#include <ExtCtrls.hpp>
#include <VCLTee.Series.hpp>
#include <VCLTee.TeEngine.hpp>
#include <VCLTee.TeeProcs.hpp>
#include <Dialogs.hpp>
#include <Vcl.HtmlHelpViewer.hpp>

//---------------------------------------------------------------------------


	   double uVAL=0;
	   double uLOVAL=0;
	   int NumValidPeaks=0;
       int NumOfCurvePoints;
       int NumBaselinePoints;     //user specified, defaults to 50
       int DigitsInNumCurvePoints;
       double USERSTD=0.05;      //holds number of STD or Tolerance(default)
	   bool USERTolerance=true;
	   bool USERSTDDEV=false;
	   bool USERDEF=false;

	   int REFFrame=0;  //CH0 frame to use to calc MEAN/STDDev

       double MEAN[4];    //calc ONLY once for all CHAN0 from srecnum0
                        //calc ONLY once for all CHAN1 from srecnum1
                        //calc ONLY once for all CHAN2 from srecnum2
                        //calc ONLY once for all CHAN3 from srecnum3

       double LOVAL[4];
       double HIVAL[4];

       double STDDEV[4];
       double VARIANCE[4];

       int PosFromCurveEnd=30;

	   const int MAXPOINTS=100000;//20000;

       double subsetfcurve1[MAXPOINTS];

       double NumHistBins;

class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TDriveComboBox *DriveComboBox1;
	TDirectoryListBox *DirectoryListBox1;
        TFileListBox *FileListBox1;
        TButton *bGetData;
        TEdit *eBaseLinePnts;
        TLabel *Label1;
        TEdit *eNumStdDev;
        TDBChart *DBChart1;
        TLineSeries *Series1;
        TPanel *Panel1;
        TScrollBar *ScrollBar1;
        TLabel *Label2;
        TLabel *sbLabel;
        TLabel *Label4;
        TEdit *tbPeak1;
        TLabel *Label5;
        TEdit *tbWidth1;
        TButton *bPlot;
        TEdit *tbYMin;
        TLabel *Label6;
        TLabel *Label8;
        TLabel *Label9;
        TEdit *tbYMax;
        TLabel *Label10;
        TLabel *Label11;
        TEdit *tbXMin;
        TEdit *tbXMax;
        TRadioGroup *RadioGroup1;
        TButton *bSaveToFile;
        TRadioGroup *rgSaveType;
        TSaveDialog *saveDlg;
        TButton *bSaveFrame;
        TListBox *lbNoWidth;
        TLabel *Label3;
        TLineSeries *Series2;
        TLineSeries *Series3;
        TLineSeries *Series4;
        TButton *bChange;
        TButton *bPrint;
        TLabel *Label7;
        TEdit *eTolerance;
        TLabel *Label12;
        TRadioGroup *rgMethod;
        TButton *bMetaFile;
        TLabel *Label13;
        TEdit *eWStrt;
        TLabel *Label14;
        TEdit *eWEnd;
        TButton *bDeleteFrame;
        TButton *bHistograms;
        TButton *bRankPlot;
        TRadioGroup *rgRankType;
	TButton *bImportPeaksWidths;
	TOpenDialog *dImportPeaksWidths;
	TEdit *eUSERVAL;
	TLabel *Label15;
	TRadioGroup *rgWhichScopeProgram;
	TScrollBar *sbShiftBLframe;
	TLabel *Label16;
	TLabel *lMoveBaseline;
	TLabel *Label17;
	TLabel *lLoBound;
	TLabel *Label18;
	TLabel *lHiBound;
        void __fastcall DirectoryListBox1Change(TObject *Sender);
        void __fastcall DriveComboBox1Change(TObject *Sender);
        void __fastcall bGetDataClick(TObject *Sender);
        void __fastcall bPlotClick(TObject *Sender);
        void __fastcall ScrollBar1Change(TObject *Sender);
        void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
        void __fastcall bSaveToFileClick(TObject *Sender);
        void __fastcall bSaveFrameClick(TObject *Sender);
        void __fastcall RadioGroup1Click(TObject *Sender);
        void __fastcall bChangeClick(TObject *Sender);
        void __fastcall bPrintClick(TObject *Sender);
        void __fastcall bMetaFileClick(TObject *Sender);
        void __fastcall bDeleteFrameClick(TObject *Sender);
        void __fastcall bHistogramsClick(TObject *Sender);
        void __fastcall bRankPlotClick(TObject *Sender);
	void __fastcall bImportPeaksWidthsClick(TObject *Sender);
	void __fastcall sbShiftBLframeChange(TObject *Sender);


private:	// User declarations
public:		// User declarations



        __fastcall TForm1(TComponent* Owner);
        int __fastcall PrelimCheckIt(void);
		void __fastcall GetBaseLineInfo(void);
        double __fastcall CnvrtData(long & bufIDX);
        void __fastcall NxtDataFld(long & bufIDX);
        bool __fastcall FindDFN(long & bufIDX);
        void __fastcall GetSnglChan(FILE *inp);
        void __fastcall GetBaseLineWidthsAndSuspects(int rec, int chan);
        void __fastcall PlotsinchandataFrame(double AXMin, double AXMax, double AYMin, double AYMax, int AAxis);
        void __fastcall SetScrollBar(int num);
        void __fastcall SaveToFileClickPeaksWidths(void);
        void __fastcall SaveToFileClickAll(void);
        void __fastcall displaySuspects(void);

        double __fastcall FindMin(double *arr);
        double __fastcall FindMax(double *arr);
        float __fastcall FindMin(float *arr);
        float __fastcall FindMax(float *arr);
        bool __fastcall ReadHeaderInfo(char *fname);
        double __fastcall FindMin(double *arr, int numPoints);
		double __fastcall FindMax(double *arr, int numPoints);
		bool __fastcall TForm1::GetNUM(AnsiString astr, int &intval, int &fails);
		bool __fastcall TForm1::GetNUM(AnsiString astr, float *arr, int idx, int &fails);
		void __fastcall TForm1::HistToScreen(int arrsz,float *arrP, float *arrS, float *arrW,FILE *f);

};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
