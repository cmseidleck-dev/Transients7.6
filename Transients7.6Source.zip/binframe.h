//Binary Frame class for single channel data for the LM148

#include <math.h>

class dataFrame {
   private:
      char head1[5];
      signed char curve1[500];
      char lf1;
      float fcurve1[500];
      float subCurve1[500];
      double fxinc[500];
      float calcSinCurve[500];
      int zeroIdx;
      float curveMax;
      void calcSinWave(void);
      void subtrCurves(void);
      float signCheck(float voltval);
      int BinIt(double timeInterval, float *fltarr);
      double interpVolt(int hi, int lo, float voltval);
      int getVoltIdx(float voltval, int frstidx);
      int getExactVoltIdx(float voltval, int frstidx);
      int getExactVoltIdx(float voltval);
      int getVoltIdx(float voltval);
   public:
      int GetdataFrame(FILE *inp);
      void CalcNewVals(double xinc, float Yoff, float Yinc, float Yzero,FILE *fd1);
      int PeakVals(float *fltarr,FILE *tmp);
      int BinPulseWidth(float *fltarr,FILE *tmp);
};

int dataFrame::GetdataFrame(FILE *inp)
{
   unsigned char ch;

   if ((fread(&head1,sizeof(head1),1,inp))!=1) return(-1);
   for (int i=0; i<500; i++) {
      if ((fread(&ch,sizeof(char),1,inp))!=1) return(-1);
      curve1[i]=ch;
   }
   if ((fread(&lf1,sizeof(lf1),1,inp))!=1)return(-1);
   return(1);
}

void dataFrame::CalcNewVals(double xinc, float Yoff, float Yinc, float Yzero,FILE *fd1)
{
   signed char *c1;

   c1=(signed char *)&curve1;
   for (int i=0; i<500; i++) {
      fcurve1[i]=c1[i];
      fxinc[i]=xinc*i;
      fcurve1[i]=(fcurve1[i]-Yoff)*Yinc+Yzero;
   }

   for (int i=0; i<500; i++) {      //find the curve "zero"
      if ((fcurve1[i]>=-0.09)&&(fcurve1[i]<=0.09)) {
         zeroIdx=i;
         break;
      }
   }
   calcSinWave();
   subtrCurves();


for (int i=0; i<500; i++)fprintf(fd1,"%le\t%f\t%f\t%f\n",fxinc[i],fcurve1[i],calcSinCurve[i],subCurve1[i]);

}

void dataFrame::subtrCurves(void)
{
   for (int i=0; i<500; i++)subCurve1[i]=fcurve1[i]-calcSinCurve[i];
}
void dataFrame::calcSinWave(void)
{
   if ((fcurve1[zeroIdx+62]>=-6)&&(fcurve1[zeroIdx+62]<=-4)){
      for (int i=0; i<500; i++)calcSinCurve[i]=-5*(sin((2*3.141593/250)*(i-zeroIdx)));
   }
  else for (int i=0; i<500; i++)calcSinCurve[i]=5*(sin((2*3.141593/250)*(i-zeroIdx)));
}

int dataFrame::PeakVals(float *fltarr,FILE *tmp)
{
   float inc;
   float binmin=fltarr[0];
   float binmax=fltarr[1];
   int numBins=(int)fltarr[2];
   int saveIdx=0;

   curveMax=subCurve1[0];
   for (int i=1; i<500; i++){
      if (fabs(subCurve1[i])>curveMax){
         curveMax=fabs(subCurve1[i]);
         saveIdx=i;
      }
   }
   curveMax=subCurve1[saveIdx];
          fprintf(tmp,"  peak %f\n",curveMax);

   inc=(binmax-binmin)/numBins;

   if (curveMax<=binmin)return(0);   //load <binmin into first endpoint

   for (int i=0; i<numBins; i++) {
      if ((curveMax>binmin)&&(curveMax<=(binmin+=inc)))return(i);
   }
   if (curveMax>binmin)return(numBins-1);  //load >binmax into sec endpoint
}

float dataFrame::signCheck(float voltval)
{
    if (curveMax<0) {
       if (voltval<=0);
       else if (voltval>0)voltval=voltval*-1;
       if (voltval<curveMax)return(10000);
       else return(voltval);
    }
    if (curveMax>0) {
       if (voltval>=0) ;
       else if (voltval<0)voltval=fabs(voltval);
       if (voltval>curveMax)return(10000);
       else return (voltval);
    }
}

int dataFrame::BinPulseWidth(float *fltarr, FILE *tmp)
{
   double frsttime,sectime;
   int frstidx,secidx;
   float val=fltarr[6],voltval;

   voltval=signCheck(val);
   if (voltval==10000)return(-1);        //no width possible

   frstidx=getExactVoltIdx(voltval); //try for exact match on first part of curve
   if (frstidx<0) {
      frstidx=getVoltIdx(voltval);
      frsttime=interpVolt(frstidx,frstidx-1,voltval);
      if (frsttime==-1)return(-1);
   }
   else frsttime=fxinc[frstidx];
   secidx=getExactVoltIdx(voltval,frstidx); //try for exact match on second part of curve
   if (secidx<0) {
      secidx=getVoltIdx(voltval,frstidx);
      sectime=interpVolt(secidx,secidx-1,voltval);
      if (sectime==-1)return(-1);
   }
   else sectime=fxinc[secidx];
     fprintf(tmp,"   %e width\n",sectime-frsttime);
   return(BinIt(sectime-frsttime,fltarr));   //time interval in nanoseconds?
}

int dataFrame::BinIt(double timeInterval, float *fltarr)
{
   float wbinmin=fltarr[3];
   float wbinmax=fltarr[4];
   int wnumbins=(int)fltarr[5];
   float inc;

   inc=(wbinmax-wbinmin)/wnumbins;

   if (timeInterval<=wbinmin)return(0);  //load <wbinmin into first endpoint
   for (int i=0; i<wnumbins; i++) {
      if ((timeInterval>wbinmin)&&(timeInterval<=(wbinmin+=inc)))return(i);
   }
   if (timeInterval>wbinmin)return(wnumbins-1); //load >binmax into sec endpoint
}

double dataFrame::interpVolt(int hi, int lo, float voltval)
{
   if ((subCurve1[lo]-subCurve1[hi])==0)return(-1);   //avoid div by 0

   return( (((voltval-subCurve1[hi])*(fxinc[lo]-fxinc[hi]))/
     (subCurve1[lo]-subCurve1[hi]))+fxinc[hi]);
}

int dataFrame::getVoltIdx(float voltval, int frstidx)
{
   if (voltval<=0) {
      for (int i=frstidx; i<500; i++)if (subCurve1[i]>voltval)return(i);
   }
   else if (voltval>0) {
      for (int i=frstidx; i<500; i++)if (subCurve1[i]<voltval)return(i);
   }
   return(-1);
}

int dataFrame::getExactVoltIdx(float voltval, int frstidx)
{
   for (int i=frstidx; i<500; i++) if (subCurve1[i]==voltval)return(i);
   return(-1);
}

int dataFrame::getExactVoltIdx(float voltval)
{
   for (int i=0; i<500; i++)if (subCurve1[i]==voltval)return(i);
   return(-1);
}

int dataFrame::getVoltIdx(float voltval)
{
   if (voltval <=0) {
      for (int i=0; i<500; i++)if (subCurve1[i]<voltval)return(i);
   }
   else if (voltval>0) {
      for (int i=0; i<500; i++)if (subCurve1[i]>voltval)return(i);
   }
   return(-1);
}
