//---------------------------------------------------------------------------

#ifndef TxtSeriesLabelH
#define TxtSeriesLabelH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <stdio.h>
//---------------------------------------------------------------------------
class TDataSeriesLabel : public TForm
{
__published:	// IDE-managed Components
	TEdit *eSeriesLabel;
	TLabel *Label1;
	TButton *bOK;
	void __fastcall bOKClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TDataSeriesLabel(TComponent* Owner);
	__fastcall TDataSeriesLabel(FILE *f, TComponent *Owner);


};
//---------------------------------------------------------------------------
extern PACKAGE TDataSeriesLabel *DataSeriesLabel;
//---------------------------------------------------------------------------
#endif
