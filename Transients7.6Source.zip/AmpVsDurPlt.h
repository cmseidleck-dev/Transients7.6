//---------------------------------------------------------------------------

#ifndef AmpVsDurPltH
#define AmpVsDurPltH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Vcl.ExtCtrls.hpp>
#include <VCLTee.Chart.hpp>
#include <VCLTee.Series.hpp>
#include <VCLTee.TeEngine.hpp>
#include <VCLTee.TeeProcs.hpp>
#include <Vcl.Dialogs.hpp>
//---------------------------------------------------------------------------
class TfAmpvsDurPlt : public TForm
{
__published:	// IDE-managed Components
	TChart *Chart1;
	TPointSeries *Series1;
	TButton *bPrint;
	TButton *bSaveTofile;
	TButton *bExport;
	TSaveDialog *dAmpDurSave;
	void __fastcall bPrintClick(TObject *Sender);
	void __fastcall bSaveTofileClick(TObject *Sender);
	void __fastcall bExportClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TfAmpvsDurPlt(TComponent* Owner);
	 __fastcall TfAmpvsDurPlt::TfAmpvsDurPlt(float *pkarr, float *subpkarr, float *widtharr,
										 int arrcnt,FILE *f,TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfAmpvsDurPlt *fAmpvsDurPlt;
//---------------------------------------------------------------------------
#endif
