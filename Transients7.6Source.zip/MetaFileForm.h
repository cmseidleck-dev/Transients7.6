//---------------------------------------------------------------------------

#ifndef MetaFileFormH
#define MetaFileFormH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <VCLTee.DBChart.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TTMetaFileForm : public TForm
{
__published:	// IDE-managed Components
        TEdit *efilename;
        TLabel *Label1;
        TBitBtn *bbOK;
        TBitBtn *bbCancel;
        void __fastcall bbOKClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TTMetaFileForm(TComponent* Owner);
        virtual __fastcall TTMetaFileForm(TDBChart *DBChart1, TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TTMetaFileForm *TMetaFileForm;
//---------------------------------------------------------------------------
#endif
