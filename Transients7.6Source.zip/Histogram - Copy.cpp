//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Histogram.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
THistogramForm *HistogramForm;
//---------------------------------------------------------------------------
__fastcall THistogramForm::THistogramForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
__fastcall THistogramForm::THistogramForm(int *pkarr, int *subpkarr, int *widtharr,
                                         double NumHistBins, float *BinValsPk,float *BinValsSub,
                                         float *BinValsWidth,TComponent* Owner)
           : TForm(Owner)
{

   DBChartPeak->Series[0]->Clear();
   DBChartSubPeak->Series[0]->Clear();
   DBChartWidth->Series[0]->Clear();
   DBChartPeak->LeftAxis->LabelStyle=talValue;
   DBChartPeak->BottomAxis->LabelStyle=talText;   //was talText
   DBChartSubPeak->LeftAxis->LabelStyle=talValue;
   DBChartSubPeak->BottomAxis->LabelStyle=talText;
   DBChartWidth->LeftAxis->LabelStyle=talValue;
   DBChartWidth->BottomAxis->LabelStyle=talText;

   AnsiString val;

   int pkarrMX=0, pkarrMN=0, subpkarrMX=0, subpkarrMN=0, widtharrMX =0, widtharrMN=0;

   for (int i=0; i<NumHistBins; i++) {
      if (pkarr[i] > pkarrMX)pkarrMX=pkarr[i];
      if (pkarr[i] < pkarrMN)pkarrMN=pkarr[i];
      if (subpkarr[i] > subpkarrMX)subpkarrMX=subpkarr[i];
      if (subpkarr[i] < subpkarrMN)subpkarrMN=subpkarr[i];
      if (widtharr[i] > widtharrMX)widtharrMX=widtharr[i];
      if (widtharr[i] < widtharrMN)widtharrMN=widtharr[i];
   }

   DBChartPeak->BottomAxis->SetMinMax(-2,NumHistBins);
   DBChartPeak->LeftAxis->SetMinMax(pkarrMN,pkarrMX);                 //comes from min/max of binned data
   for (int i=0; i<NumHistBins; i++){
      val=FloatToStrF(BinValsPk[i],ffExponent,7,2);  //was 1,1
      DBChartPeak->Series[0]->AddY(pkarr[i],val,clTeeColor);
   }
   DBChartSubPeak->BottomAxis->SetMinMax(-2,NumHistBins);
   DBChartSubPeak->LeftAxis->SetMinMax(subpkarrMN,subpkarrMX);                 //comes from min/max of binned data
   for (int i=0; i<NumHistBins; i++){
      val=FloatToStrF(BinValsSub[i],ffExponent,1,1);
      DBChartSubPeak->Series[0]->AddY(subpkarr[i],val,clTeeColor);
   }

   DBChartWidth->BottomAxis->SetMinMax(-2,NumHistBins);
   DBChartWidth->LeftAxis->SetMinMax(widtharrMN,widtharrMX);                 //comes from min/max of binned data
   for (int i=0; i<NumHistBins; i++){
      val=FloatToStrF(BinValsWidth[i],ffExponent,1,1);
      DBChartWidth->Series[0]->AddY(widtharr[i],val,clTeeColor);
   }

}
//------------------------------------------------------------------------------
__fastcall THistogramForm::THistogramForm(int *pkarr, float *BinValsPk,double NumHistBins,
                                          int *subpkarr, float *BinValsSub,double NumHistBinsS,
                                          int *widtharr, float *BinValsWidth, double NumHistBinsW,
                                          TComponent* Owner)
       : TForm(Owner)
{
   DBChartPeak->Series[0]->Clear();
   DBChartSubPeak->Series[0]->Clear();
   DBChartWidth->Series[0]->Clear();

   DBChartPeak->LeftAxis->LabelStyle=talValue;
   DBChartPeak->BottomAxis->LabelStyle=talText;
   DBChartSubPeak->LeftAxis->LabelStyle=talValue;
   DBChartSubPeak->BottomAxis->LabelStyle=talText;
   DBChartWidth->LeftAxis->LabelStyle=talValue;
   DBChartWidth->BottomAxis->LabelStyle=talText;

   AnsiString val;

   int pkarrMX=pkarr[0], pkarrMN=pkarr[0], subpkarrMN=subpkarr[0], subpkarrMX=subpkarr[0], widtharrMX=widtharr[0], widtharrMN=widtharr[0];                            //peaks

   for (int i=1; i<NumHistBins; i++) {
      if (pkarr[i] > pkarrMX)pkarrMX=pkarr[i];
      if (pkarr[i] < pkarrMN)pkarrMN=pkarr[i];
   }
   DBChartPeak->LeftAxis->SetMinMax(pkarrMN,pkarrMX);
   DBChartPeak->LeftAxis->Increment=(pkarrMX-pkarrMN)/10;

   DBChartPeak->BottomAxis->SetMinMax(-1,NumHistBins);
                    //comes from min/max of binned data
   for (int i=0; i<NumHistBins; i++){
      val=FloatToStrF(BinValsPk[i],ffExponent,1,1);
      DBChartPeak->Series[0]->AddY(pkarr[i],val,clTeeColor);
   }

   for (int i=1; i<NumHistBinsS; i++) {                            //abs subpks
      if (subpkarr[i] > subpkarrMX)subpkarrMX=subpkarr[i];
      if (subpkarr[i] < subpkarrMN)subpkarrMN=subpkarr[i];
   }
   DBChartSubPeak->LeftAxis->SetMinMax(subpkarrMN,subpkarrMX);
   DBChartSubPeak->BottomAxis->SetMinMax(-1,NumHistBinsS);
   for (int i=0; i<NumHistBinsS; i++){
      val=FloatToStrF(BinValsSub[i],ffExponent,1,1);
      DBChartSubPeak->Series[0]->AddY(subpkarr[i],val,clTeeColor);
   }

   for (int i=1; i<NumHistBinsW; i++) {                           //widths
      if (widtharr[i] > widtharrMX)widtharrMX=widtharr[i];
      if (widtharr[i] < widtharrMN)widtharrMN=widtharr[i];
   }

   DBChartWidth->LeftAxis->SetMinMax(widtharrMN,widtharrMX);
   DBChartWidth->BottomAxis->SetMinMax(-1,NumHistBinsW);
   for (int i=0; i<NumHistBinsW; i++) {
      val=FloatToStrF(BinValsWidth[i],ffExponent,1,1);
      DBChartWidth->Series[0]->AddY(widtharr[i],val,clTeeColor);
   }


}
//------------------------------------------------------------------------------
void __fastcall THistogramForm::bPrintClick(TObject *Sender)
{
   DBChartPeak->PrintLandscape();
   DBChartSubPeak->PrintLandscape();
   DBChartWidth->PrintLandscape();
}
//---------------------------------------------------------------------------

