//---------------------------------------------------------------------------

#include <vcl.h>

#include <stdio.h>


#pragma hdrstop

#include "RayMethod.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TWeighted *Weighted;


int numvalidpeaks;
float mnpk,mxpk,mnrank,mxrank,*pkarr,*rankarr;

//---------------------------------------------------------------------------
__fastcall TWeighted::TWeighted(TComponent* Owner)
        : TForm(Owner)
{


}
//---------------------------------------------------------------------------
 __fastcall TWeighted::TWeighted(char *type,AnsiString fname,int NumValidPeaks,float MNpk,float MXpk,
                                 float MNrank,float MXrank,float *PKarr, float *RANKarr,
                                 TComponent *Owner)
            :TForm(Owner)
{
   numvalidpeaks=NumValidPeaks;
   mnpk=MNpk;
   mxpk=MXpk;
   mnrank=MNrank;
   mxrank=MXrank;
   pkarr=PKarr;
   rankarr=RANKarr;
   AnsiString titl;
   wchar_t wtitl[200];

   DBChart1->Series[0]->Clear();
//   DBChart1->LeftAxis->LabelStyle=talValue;
   DBChart1->BottomAxis->LabelStyle=talText;

   AnsiString val;

  DBChart1->BottomAxis->SetMinMax(mnrank,mxrank);
  DBChart1->LeftAxis->SetMinMax(mnpk-0.005,mxpk+0.005);

   DBChart1->LeftAxis->Increment=abs(mxpk)/5;
   if (mxpk<=1)DBChart1->LeftAxis->Increment=0.005;

   titl.sprintf("%s %s",fname,type);
   titl.WideChar(wtitl,200);
//   sprintf(titl,"%s %s",fname,type);
   DBChart1->Title->Text->SetText(wtitl);

   for (int i=0; i<numvalidpeaks; i++){
      val=FloatToStrF(rankarr[i],ffExponent,1,1);
      DBChart1->Series[0]->AddXY(rankarr[i],pkarr[i],val,clTeeColor);
        FILE *f=fopen("plot.out","at");
         fprintf(f,"%f\t%f\n",rankarr[i],pkarr[i]);
         fclose(f);
   }
}//---------------------------------------------------------------------------
void __fastcall TWeighted::bChangeRankClick(TObject *Sender)
{
   double AXMin,AXMax,AYMin,AYMax;
   int szXmin,szXmax,szYmin,szYmax;

   AnsiString str;

   szXmin=Xmin->GetTextLen();
   szXmax=Xmax->GetTextLen();
   szYmin=Ymin->GetTextLen();
   szYmax=Ymax->GetTextLen();

   if (szXmin<1) {
	  Application->MessageBox(L"Enter X Min",L"USER ERROR",MB_OK);
      Xmin->SetFocus();
      return;
   }
   if (szXmax<1) {
	  Application->MessageBox(L"Enter X Max",L"USER ERROR",MB_OK);
      Xmax->SetFocus();
      return;
   }
   if (szYmin<1) {
	  Application->MessageBox(L"Enter Y Min",L"USER ERROR",MB_OK);
      Ymin->SetFocus();
      return;
   }
   if (szYmax<1) {
      Application->MessageBox(L"Enter Y Max",L"USER ERROR",MB_OK);
      Ymax->SetFocus();
      return;
   }

   wchar_t *buf=new wchar_t[szXmin+1];  //char *buf=new char[szXmin+1];
   Xmin->GetTextBuf(buf,szXmin+1);
   str.sprintf("%s",buf);
   AXMin=str.ToDouble();        // AXMin=atof(buf);
   delete [] buf;

   wchar_t *buf2=new wchar_t[szXmax+1]; //char *buf2=new char[szXmax+1];
   Xmax->GetTextBuf(buf2,szXmax+1);
   str.sprintf("%s",buf2);
   AXMax=str.ToDouble();               //AXMax=atof(buf2);
   delete [] buf2;

   wchar_t *buf3=new wchar_t[szYmin+1];  //char *buf3=new char[szYmin+1];
   Ymin->GetTextBuf(buf3,szYmin+1);
   str.sprintf("%s",buf3);
   AYMin=str.ToDouble();   // AYMin=atof(buf3);
   delete [] buf3;

   wchar_t *buf4=new wchar_t[szYmax+1]; // char *buf4=new char[szYmax+1];
   Ymax->GetTextBuf(buf4,szYmax+1);
   str.sprintf("%s",buf4);
   AYMax=str.ToDouble();  //AYMax=atof(buf4);
   delete [] buf4;

    DBChart1->Series[0]->Clear();
   DBChart1->LeftAxis->LabelStyle=talValue;
   DBChart1->BottomAxis->LabelStyle=talText;

   AnsiString val;


  DBChart1->BottomAxis->SetMinMax(AXMin,AXMax);
  DBChart1->LeftAxis->SetMinMax(AYMin-0.005,AYMax+0.005);

  DBChart1->LeftAxis->Increment=abs(mxpk)/5;
   if (mxpk<=1)DBChart1->LeftAxis->Increment=0.005;


   for (int i=0; i<numvalidpeaks; i++){
      val=FloatToStrF(rankarr[i],ffExponent,1,1);
      DBChart1->Series[0]->AddXY(rankarr[i],pkarr[i],val,clTeeColor);

   }

}
//---------------------------------------------------------------------------

void __fastcall TWeighted::Button1Click(TObject *Sender)
{
   DBChart1->PrintLandscape();
}
//---------------------------------------------------------------------------

