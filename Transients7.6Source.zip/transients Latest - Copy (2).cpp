//---------------------------------------------------------------------------
//Version 6.1 New Scope format

#include <vcl.h>
#include <stdio.h>
#include <stdlib>
#include <string.h>
#include <io.h>
#include <exception>
#include <iostream.h>
#include <dir.h>
#include <sys\stat.h>
#include <vector>
#include <iterator>
#include <ctype.h>
#include "Math.hpp"
#include <algorithm>
#include <vector>
#include <tchar.h>
#include <fstream>  //ifstream, ofstream
#include <iostream.h>

#include <fcntl.h>

#pragma hdrstop

#include "transients.h"
#include "sinchandataframe.h"
#include "FSaveForm.h"
#include "MetaFileForm.h"
#include "Histogram.h"
#include "RayMethod.h"
#include "AmpVsDurPlt.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
using namespace std;


const int MAXnumFrames=800;

sinchandataFrame *sfdata[MAXnumFrames];
TCursor oldCursor;

//char fname[200];
AnsiString fname;

int CHANfromHDR;
int FRAMES,CHANNELS;
long INPUTFSIZE;
unsigned char *WholeFILEBUF;

int CHAN=0;  //default is channel1 for startup
int srecnum=-1; //frames*channels

FILE *inp;
FILE *myFile;
char titl[250];
double xinc[MAXPOINTS];
float curve1[MAXPOINTS];
float mmean[MAXPOINTS];
float subcurve1[MAXPOINTS];   //kEEP
float fltarr[7];   //used for binning and voltval operations
char outname[200];  //file name to record binning information
int desiredRec;  //desiredRec=(desiredRec*hdrcls->channels)+CHAN; //frame&chan are zero based


bool NumCHANSFound=false;   //2011 update of data with #CHANs in Header comment

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{

}
//---------------------------------------------------------------------------
void __fastcall TForm1::SetScrollBar(int num)
{
   ScrollBar1->Min=0;
   if (num>0)ScrollBar1->Max=num-1;
   else ScrollBar1->Max=0;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::DirectoryListBox1Change(TObject *Sender)
{
   FileListBox1->Directory=DirectoryListBox1->Directory;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::DriveComboBox1Change(TObject *Sender)
{
   DirectoryListBox1->Drive=DriveComboBox1->Drive;
}
//----------------------------------------------------------------------------

bool __fastcall TForm1::ReadHeaderInfo(char *fname)
{
   FILE *infile;
   unsigned char Header[2000];
   unsigned char ch0,ch1,ch2,*ch;
   AnsiString AHeader;
   bool NewFormat=true;

   Header[0]='\0';

   if ( (infile=fopen(fname,"rt"))==NULL ) {
      Application->MessageBox(L"Cannot determine file type",L"APPERR",MB_OK);
      return false;
   }
   ch0=fgetc(infile);
   ch1=fgetc(infile);
   ch2=fgetc(infile);

   int count=2;

   while ((ch0!='/')&&(ch1!='*')&&(ch2!='*')&&(count<100)) {     //only check for comments in first 100 characters
      ch0=ch1;
      ch1=ch2;
      ch2=fgetc(infile);
      count++;
   }
   int idx=0;
   bool endIT=false;
   if ((ch0=='/')&&(ch1=='*')&&(ch2=='*')&&(count<100)) {
      ch0=0;ch1=0,ch2=0;
      do{
         ch0=ch1;
         ch1=ch2;
         ch2=fgetc(infile);
         if ((ch0=='*')&&(ch1=='*')&&(ch2=='/'))endIT=true;
         ch=&ch2;
         Header[idx]=*ch;
         idx++;
      }while((!endIT)&&(!feof(infile)));
      Header[idx]='\0';
   }
   else NewFormat=false;
   fclose(infile);

   if (NewFormat) {
      AnsiString HDR;
      int pos;
      HDR.cat_sprintf("%s,", Header);
      HDR=HDR.UpperCase();
      if (HDR.Pos("ADT SCOPE PROGRAM_V1.")==0)NewFormat=false;
      else {
         pos=HDR.Pos("TOTAL CHS:");
         HDR=HDR.SubString(pos+11,1);
         CHANfromHDR=atoi(HDR.c_str());
         NumCHANSFound=true;
      }
   }
   return(NewFormat);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::bGetDataClick(TObject *Sender)
{



   int fh;
   bool type=true;  //default is new format, false is old

   char ch,*s,drive[MAXDRIVE],dir[MAXDIR],file[MAXFILE],ext[MAXEXT];
   bool dataFound=false;

   CHANNELS=1;  //init to one channel per frame

   if ((PrelimCheckIt())<0)return;     //checks for data files selected

   if (srecnum!=0)for (int i=0; i<srecnum; i++)delete sfdata[i];
//   if(srecnum!=0)delete [] sfdata;
   srecnum=0;
   fname=FileListBox1->FileName.c_str();
   //strcpy(fname,FileListBox1->FileName.c_str()); //get filename for use in naming output files
   sprintf(outname,"%s",fname);  //load fname into outname

   fh=open(fname.c_str(),_O_RDONLY | O_BINARY);
   INPUTFSIZE=filelength(fh);
   close(fh);

   WholeFILEBUF=new unsigned char[INPUTFSIZE];

   s=fname.c_str();
   fnsplit(s,drive,dir,file,ext);
   sprintf(titl,"%s ",file);             //get input file name for plot title

   inp=fopen(fname.c_str(),"rb");           //open input file for BINARY read ONLY
   fread(WholeFILEBUF,INPUTFSIZE,1,inp);
   fclose(inp);

   GetBaseLineInfo();         //load user specified #baseline points to be used
   type=ReadHeaderInfo(fname.c_str());

   TCursor save_Cursor = Screen->Cursor;
   Screen->Cursor = crHourGlass;
   try {
      srecnum=0;
      GetSnglChan(inp);
   }
   __finally {
      Screen->Cursor = save_Cursor;
   }

   SetScrollBar(srecnum/CHANNELS); //show only the FRAME count
   RadioGroup1->ItemIndex=0;  //start with channel 1
   displaySuspects();
   delete [] WholeFILEBUF;

}
//-----------------------------------------------------------------------------
void __fastcall TForm1::GetSnglChan(FILE *inp)
{

   char ch,pointArr[MAXPOINTS];
   int DFN,Time,CH,OldDFN=0;      //OldCH=1;
   double XINC,YINC,YPOS,YOFF;
   int NumDigits;
   long bufIDX=0;
   char *ctmp;

   bool DFNFound;  //CHcounted=false;

   char cDFN[6],cTime[20],cCH[2];

     FILE *tmp=fopen("DFN.dat","wt");

   CHANNELS=0;                         //**new

   while ( (bufIDX<INPUTFSIZE)&& (srecnum<MAXnumFrames)) {

      DFNFound=FindDFN(bufIDX);
	  if (DFNFound) {

		 for (int m=0; m<5; m++){
            cDFN[m]=WholeFILEBUF[bufIDX];
            bufIDX++;
         }
         DFN=atoi(cDFN);

         if (OldDFN==DFN)CHANNELS++;       //**new
         else if (OldDFN!=DFN)CHANNELS=1;  //**new

         OldDFN=DFN;

         NxtDataFld(bufIDX);
		 NxtDataFld(bufIDX);

		 int m=0;
		 while((WholeFILEBUF[bufIDX]!=';')&&(m<20)){
			cTime[m]=WholeFILEBUF[bufIDX];
			m++;
			bufIDX++;
		 }

 /*        for (int m=0;m<9;m++) {
			cTime[m]=WholeFILEBUF[bufIDX];
            bufIDX++;
		 }  */
         Time=atoi(cTime);

         for (int m=0; m<3; m++)bufIDX++; //get rid of semicolon, 'C','H'
         cCH[0]=WholeFILEBUF[bufIDX];
         CH=atoi(cCH);

         NxtDataFld(bufIDX);
         XINC=CnvrtData(bufIDX);

         NxtDataFld(bufIDX);
         YINC=CnvrtData(bufIDX);

         NxtDataFld(bufIDX);
         YPOS=CnvrtData(bufIDX);

         NxtDataFld(bufIDX);
         YOFF=CnvrtData(bufIDX);
                                   //determines whether this is OLD format
         if (WholeFILEBUF[++bufIDX]=='#')bufIDX++;     //should now point at 3chars in NumPointsInLine ***********NEW


         else {                    //this is the new format2/2011
            NxtDataFld(bufIDX);     //get past this bogus new  YZORo field      //*NEW
            CnvrtData(bufIDX);     //don't need to keep this field              //*NEW
            bufIDX=bufIDX+2; //should now point at 3chars in NumPointsInLine    //*NEW
         }                                                                      //*NEW

         NumDigits=((int)(WholeFILEBUF[bufIDX]))-48;   //number of digits in NumPointsInLine
         bufIDX++;

         ctmp=new char[NumDigits+1];
         for (int z=0; z<NumDigits+1; z++)ctmp[z]='\0';

         for (int m=0; m<NumDigits; m++) {
            ctmp[m]=WholeFILEBUF[bufIDX];
            bufIDX++;
         }

         NumOfCurvePoints=atoi(ctmp);
         delete [] ctmp;
         int i;

         if (NumOfCurvePoints!=0){
            for (i=0;i<NumOfCurvePoints; i++){
               pointArr[i]=WholeFILEBUF[bufIDX];
               bufIDX++;

            }
			sfdata[srecnum]=new sinchandataFrame; //get all channels for each frame
            sfdata[srecnum]->GetdataFrame(pointArr,Time);    //(pointArr,NumOfCurvePoints,NumBaselinePoints,Time);
            sfdata[srecnum]->CalcNewVals(XINC,YINC,YPOS,YOFF,pointArr);

			srecnum++;


         }//NumOfCurvePoints!=0

         fprintf(tmp,"%d\t%d\tCH%d\t%e\t%e\t%e\t%e\tSREC=%d\n",DFN,Time,CH,XINC,YINC,YPOS,YOFF,srecnum);

      }//end if DFNFound

   }//this is the end of input
   fclose(tmp);

   if (NumCHANSFound)if (CHANfromHDR!=CHANNELS)CHANNELS=CHANfromHDR;

   for (int m=0; m<CHANNELS; m++){
      sfdata[m]->GetMeanStdDev(m);   //get MEAN0->CHANNELS-1
   }

   int chan=0;
   for (int recs=0; recs<srecnum; recs++) {

      sfdata[recs]->FindPeak(chan);
      GetBaseLineWidthsAndSuspects(recs,chan); //pass fcnwt(now DFN) only for list display  DETERMINES WIDTH calc

      if      (CHANNELS==2)if (chan<1)chan++;
                           else chan=0;
      else if (CHANNELS==3)if (chan<2)chan++;
                           else chan=0;
      else if (CHANNELS==4)if (chan<3)chan++;
                           else chan=0;
   }

   FRAMES=DFN;  //total Number of FRAMES=last DFN (zero based)
   CHAN=0;  //nominally set for channel 1
}
//---------------------------------------------------------------------------
void __fastcall TForm1::GetBaseLineWidthsAndSuspects(int rec, int chan)
{
   //have to pass in recnum (as rec) voltdiffchangeclick only recalculates one channel  NOT to be USED
   //getSinglChan uses global srecnum (has to pass it in so both can use this routine


   sfdata[rec]->FindPulseWidthMovAVG(fltarr,1,myFile,chan);


}
//---------------------------------------------------------------------------

void __fastcall TForm1::bPlotClick(TObject *Sender)
{
   long elapsedTime=0;
   char BAtitl[100];

//   if (ErrInProg)return;
   if (srecnum==-1)return;
   AnsiString pos=ScrollBar1->Position;
   desiredRec=pos.ToInt();  //desired rec must be modified for multichannel
   desiredRec=(desiredRec*CHANNELS)+CHAN;    //chan is zero based
   if (desiredRec>0)
      elapsedTime=( (sfdata[desiredRec]->GetTime())-(sfdata[desiredRec-1]->GetTime()) );
   sprintf(BAtitl,"Time Elapsed: %ld",elapsedTime);
   DBChart1->BottomAxis->Title->Caption=BAtitl;
   PlotsinchandataFrame(0,0,0,0,0);

}
//---------------------------------------------------------------------------
void __fastcall TForm1::PlotsinchandataFrame(double AXMin, double AXMax, double AYMin, double AYMax, int AAxis)
{                        // Axis=0- normal, calculate x and y min/max
						// Axis=1-use user AXMin,AXMax,AYMin,AYMax

   AnsiString str;     //pltitl[250],
   wchar_t wstr[10];
   AnsiString pltitl;
   wchar_t wpltitl[300];
   float peak1,peak2;
   int curve;
//   bool MPH=true;
   double width,STRT,END;
   double xmin,xmax,ymin,ymax;
   int sign;

   AnsiString num;
   _TUCHAR cnum[10];
   wchar_t wnum[10];

   double mean,stddev,LoVal[MAXPOINTS],HiVal[MAXPOINTS];

   FILE *fle;
   fle=fopen("ax.dat","wt");

   DBChart1->Series[0]->Clear();
   DBChart1->Series[1]->Clear();
   DBChart1->Series[2]->Clear();
   DBChart1->Series[3]->Clear();

   tbPeak1->Clear();  //erase any previous frame's values
   tbWidth1->Clear();

   if (sfdata[desiredRec]) {   //check if rec EXISTS
      if (sfdata[desiredRec]->IsDeleted()){     //this frame has been deleted
         Application->MessageBox(L"This Frame has been deleted from the analysis",L"User Error",
                                MB_OK);
         return;
      }

      sfdata[desiredRec]->GetFXinc(xinc);
      sfdata[desiredRec]->GetFCurve1(curve1);
      sfdata[desiredRec]->GetMMean(mmean);

      for (int z=0; z<NumOfCurvePoints; z++){
         HiVal[z]=HIVAL[CHAN];
         LoVal[z]=LOVAL[CHAN];
      }


      DBChart1->LeftAxis->LabelStyle=talValue;
	  DBChart1->BottomAxis->LabelStyle=talText;

      if (AAxis==1) {                     //user specified axis ranges
         ymin=AYMin;
         ymax=AYMax;
         DBChart1->BottomAxis->SetMinMax(AXMin,AXMax);
         DBChart1->LeftAxis->SetMinMax(AYMin,AYMax);
      }
      else {                          //automatic axis calculation
         xmin=FindMin(xinc);
         xmax=FindMax(xinc);
         ymin=FindMin(curve1);
         ymax=FindMax(curve1);
         DBChart1->BottomAxis->SetMinMax(xmin,xmax);
         DBChart1->LeftAxis->SetMinMax(ymin,ymax);
//         num=FloatToStrF(xmin,ffExponent,2,5);      //all were done this way in old conpiler non UNICODE

		 num.sprintf("%e",xmin);
		 num.WideChar(wnum,15);
			fprintf(fle,"%s\n",wnum);
		 tbXMin->SetTextBuf(wnum);

		 num.sprintf("%e",xmax);
		 num.WideChar(wnum,15);
			 fprintf(fle,"%s\n",wnum);
		 tbXMax->SetTextBuf(wnum);

		 num.sprintf("%e",ymin);
		 num.WideChar(wnum,15);
			fprintf(fle,"%s\n",wnum);
		 tbYMin->SetTextBuf(wnum);

		 num.sprintf("%e",ymax);
		 num.WideChar(wnum,15);
			fprintf(fle,"%s\n",wnum);
		 tbYMax->SetTextBuf(wnum);

      }
          fclose(fle);

      if(fabs(ymax-ymin)>0)DBChart1->LeftAxis->Increment=(fabs(ymax-ymin))/5;     //new
      else {
         ymin=ymax-0.5;
         ymax=ymax+0.5;
         DBChart1->LeftAxis->Increment=(fabs(ymax-ymin))/5;
         if(DBChart1->LeftAxis->Increment==0)DBChart1->LeftAxis->Increment=0.1;  //end new
         DBChart1->LeftAxis->SetMinMax(ymin,ymax);
      }
   //   DBChart1->LeftAxis->Increment=abs((FindMax(curve1)))/5;

  //	  sprintf(pltitl,"%s Frame %d Chan %d ID(%d)",titl,desiredRec/CHANNELS,
  //											   CHAN+1,desiredRec);
	  pltitl.cat_sprintf("%s Frame %d Chan %d ID(%d)",titl,desiredRec/CHANNELS,
											   CHAN+1,desiredRec);
	  pltitl.WideChar(wpltitl,300);

	  DBChart1->Title->Text->SetText(wpltitl);
	  AnsiString val;
	  for (int i=0; i<NumOfCurvePoints; i++) {
         val=FloatToStrF(xinc[i],ffExponent,1,1);
         DBChart1->Series[0]->AddXY(xinc[i],curve1[i],val,clTeeColor);
         DBChart1->Series[1]->AddXY(xinc[i],LoVal[i],"",clTeeColor);
         DBChart1->Series[2]->AddXY(xinc[i],HiVal[i],"",clTeeColor);
         DBChart1->Series[3]->AddXY(xinc[i],mmean[i],"",clTeeColor);
      }

	  peak1=sfdata[desiredRec]->GetPeakVal();    //put frame peaks on screen
	  str.sprintf("%f",peak1);
//	  str.WideChar(wstr,10);

//	  sprintf(str,"%f",peak1);
	  tbPeak1->Text=str;

	  width=sfdata[desiredRec]->GetWidth1Val();
	  str.sprintf("%5.3e",width);
//	  sprintf(str,"%5.3e",width);
      if (width>0)tbWidth1->Text=str;

      sfdata[desiredRec]->GetStrtEnd(STRT,END);  //get strt and end pos for width calc
	  str.sprintf("%5.3e",STRT);
//	  sprintf(str,"%5.3e",STRT);
	  eWStrt->Text=str;

	  str.sprintf("%5.3e",END);
//	  sprintf(str,"%5.3e",END);
      eWEnd->Text=str;



   } //end If record EXISTS
}
//----------------------------------------------------------------------------


double __fastcall TForm1::CnvrtData(long & bufIDX)
{
   char cnvrtdata[10];
   for (int i=0; i<10; i++)cnvrtdata[i]='\0';
   int cntr=0;

   while (WholeFILEBUF[bufIDX]!=';') {
      cnvrtdata[cntr]=WholeFILEBUF[bufIDX];
      cntr++;
      bufIDX++;
   }
   return(atof(cnvrtdata));
}
//----------------------------------------------------------------------------
void __fastcall TForm1::NxtDataFld(long & bufIDX)
{
   while (WholeFILEBUF[bufIDX]!=':')bufIDX++;
   bufIDX++;
}
//---------------------------------------------------------------------------

bool __fastcall TForm1::FindDFN(long & bufIDX)
{
    int cnt=0;

    do {
       if (WholeFILEBUF[bufIDX]=='D') {
          cnt++;
          bufIDX++;
          if ((WholeFILEBUF[bufIDX]=='F')&&(cnt==1)) {
             cnt++;
             bufIDX++;
             if ((WholeFILEBUF[bufIDX]=='N')&&(cnt==2)) {
                cnt++;
                bufIDX++;
             }
          }
       }
       else {
          cnt=0;
          bufIDX++;
       }
    }while ((cnt<3)&&(bufIDX<INPUTFSIZE));

    if (cnt==3) {
       if (WholeFILEBUF[bufIDX]==':')bufIDX++;
       return(true);
    }
    else return(false);        //EOF

}
//---------------------------------------------------------------------------


void __fastcall TForm1::GetBaseLineInfo(void)
{                         //default is first 50 line points to det baseline
   int sz=eBaseLinePnts->GetTextLen();
   if (sz!=0) {
      try {
         NumBaselinePoints = (eBaseLinePnts->Text).ToInt();
      }catch (const EConvertError &e) {
		 Application->MessageBox(L"Invalid #Curve Points-using default",L"USER ERR",
                     MB_OK);
         NumBaselinePoints=50;
      }
   }

   if (rgMethod->ItemIndex==0) {

	  sz=eNumStdDev->GetTextLen();
      if (sz!=0) {
         try {
			USERSTD = (eNumStdDev->Text).ToDouble();
         }catch (const EConvertError &e) {
			Application->MessageBox(L"Invalid #STDDEV-using default of 3",L"USER ERR",
                     MB_OK);
            USERSTD=3;
         }
         USERTolerance=false;
      }
   }
   else {
      sz=eTolerance->GetTextLen();
      if (sz!=0) {
         try {
            USERSTD = (eTolerance->Text).ToDouble();
         }catch (const EConvertError &e) {
			Application->MessageBox(L"Invalid #Tolerance-using default of 5%",L"USER ERR",
                      MB_OK);
            USERSTD=5;
         }
         USERSTD=USERSTD*0.01;
         USERTolerance=true;
      }
   }

}

//---------------------------------------------------------------------------
int __fastcall TForm1::PrelimCheckIt(void)
{
   if (FileListBox1->ItemIndex==-1) {
      Application->MessageBox(L"No data file has been selected",L"User Error",
                              MB_OK);
      return(-1);
   }
   return(0);
}
//---------------------------------------------------------------------------


double __fastcall TForm1::FindMin(double *arr)
{
   double min=arr[0];
   for (int i=1; i<NumOfCurvePoints; i++)if (arr[i]<min)min=arr[i];
   return(min);
}
//----------------------------------------------------------------------------
double __fastcall TForm1::FindMax(double *arr)
{
   double max=arr[0];
   for (int i=1; i<NumOfCurvePoints; i++)if (arr[i]>max)max=arr[i];
   return(max);
}
//----------------------------------------------------------------------------


double __fastcall TForm1::FindMin(double *arr, int numPoints)
{
   double min=arr[0];
   for (int i=1; i<numPoints; i++)if (arr[i]<min)min=arr[i];
   return(min);
}
//----------------------------------------------------------------------------
double __fastcall TForm1::FindMax(double
 *arr, int numPoints)
{
   double max=arr[0];
   for (int i=1; i<numPoints; i++)if (arr[i]>max)max=arr[i];
   return(max);
}
//----------------------------------------------------------------------------
float __fastcall TForm1::FindMin(float *arr)
{
   float min=arr[0];
   for (int i=1; i<NumOfCurvePoints; i++)if (arr[i]<min)min=arr[i];
   return(min);
}
//----------------------------------------------------------------------------
float __fastcall TForm1::FindMax(float *arr)
{
   float max=arr[0];
   for (int i=1; i<NumOfCurvePoints; i++)if (arr[i]>max)max=arr[i];
   return(max);
}

//----------------------------------------------------------------------------
void __fastcall TForm1::ScrollBar1Change(TObject *Sender)
{
   if (srecnum==-1)return;
   sbLabel->Caption=ScrollBar1->Position;

}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormClose(TObject *Sender, TCloseAction &Action)
{

   if (Application->MessageBox(L"Close Application?",L"Close?",MB_YESNO)==mrYes) {
      if (srecnum!=0)for (int i=0; i<srecnum; i++)delete sfdata[i];
      Action=caFree;
   }
   else
      Action=caNone;

}
//---------------------------------------------------------------------------

void __fastcall TForm1::bSaveToFileClick(TObject *Sender)
{
   if (rgSaveType->ItemIndex==-1)return;
   else if (rgSaveType->ItemIndex==0)SaveToFileClickAll();
   else if (rgSaveType->ItemIndex==1)SaveToFileClickPeaksWidths();
   else return;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::SaveToFileClickPeaksWidths(void)
{                      //saves Peaks and Widths ONLY for all chans of all frames
                       //(uses srecnum)

   FILE *f;

   float peak1,subpeak1;
   double width1;
   int NumChans=0;

   int curChan=0;

   AnsiString OUTFILE;

   if (srecnum==-1)return;
   if (saveDlg->Execute()) {
	  OUTFILE=saveDlg->FileName;
	  if ((f=fopen(OUTFILE.c_str(),"wt"))==NULL) {
		 Application->MessageBox(L"Error opening file for save",
                         L"USER ERROR",MB_OK);
         return;
      }
      NumChans=CHANNELS;

      fprintf(f,"REC\tCH\tPeak1\tSubPeak1\tWidth1\n");

      for (int i=0; i<srecnum; i++) {
         if (!(sfdata[i]->IsDeleted()))
         {
            peak1=sfdata[i]->GetPeakVal();
            subpeak1=sfdata[i]->GetSubPeakVal();
            width1=sfdata[i]->GetWidth1Val();

            fprintf(f,"%d\t%d\t%e\t%e\t%e\n",i,curChan,peak1,subpeak1,width1);


         }//end if not deleted
         if (curChan<NumChans-1)curChan++;
         else curChan=0;
      } //end for
      fclose(f);
   } //end dialog execute
}
//----------------------------------------------------------------------------

void __fastcall TForm1::SaveToFileClickAll(void) //MaxnumFrames=2000 set above CAREFUL not to overrun heap
{         //saves all channels (and all curve points)  of all frames (uses srecnum)
//No headers
//format of output:  Xcoord\t Yframe0CH0 \t...\t Yframe0CH3\t Yframe1CH0 \t...\tYframe1CH3\t...\tYframeNCH0 \t...\tYframeNCH3\n

   FILE *f;
   float (*arr)[MAXnumFrames];    //allocate on heap--too big for stack w/max=2000
   AnsiString OUTFILE;

   if (srecnum==-1)return;
   if (saveDlg->Execute()) {
	  OUTFILE=saveDlg->FileName;
      if ((f=fopen(OUTFILE.c_str(),"wt"))==NULL) {
         Application->MessageBox(L"Error opening file for save",
						 L"USER ERROR",MB_OK);
         return;
      }
      arr=new float[NumOfCurvePoints][MAXnumFrames];            //*****changed

      sfdata[0]->GetFXinc(xinc);

      int adjustedSRECNUM=srecnum;
      int frameIdx=0;

      for (int i=0; i<srecnum; i++) { //get all frame curves
         if (sfdata[i]->IsDeleted())adjustedSRECNUM--;
         else {
            sfdata[i]->GetFCurve1(curve1);
			for (int j=0; j<NumOfCurvePoints; j++)arr[j][frameIdx]=curve1[j];  //move frame data to table for row print
            frameIdx++;  //doesn't get bumped if IsDeleted
         }//end else NOT deleted
      }
      for (int i=0; i<NumOfCurvePoints; i++) {
         fprintf(f,"%le\t",xinc[i]);    //print xinc
         for (int j=0; j<adjustedSRECNUM; j++)fprintf(f,"%f\t",arr[i][j]); //print all channels/all frames

         fprintf(f,"\n");
      }

      fclose(f);
      delete[] arr;
   }
}
//------------------------------------------------------------------------------

void __fastcall TForm1::bSaveFrameClick(TObject *Sender)
{
   if (srecnum==-1)return;
   int NUMOfcurvepoints=NumOfCurvePoints;
   TFileSaveForm *fsf = new TFileSaveForm(xinc,curve1,subcurve1,mmean,this,NUMOfcurvepoints);
   fsf->ShowModal();
   delete fsf;

}
//---------------------------------------------------------------------------

void __fastcall TForm1::RadioGroup1Click(TObject *Sender)
{

   if (srecnum==-1) return;  //file hasn't been loaded yet

   if ((RadioGroup1->ItemIndex)>(CHANNELS-1)) {
	  Application->MessageBox(L"Channel N/A",L"USER ERR",MB_OK);
	  RadioGroup1->ItemIndex=0;
	  return;
   }
   CHAN=RadioGroup1->ItemIndex;  //reset GLOBAL CHAN::0=chan1,1=chan2,2=chan3,3=chan4
   displaySuspects();
}
//----------------------------------------------------------------------------

void __fastcall TForm1::displaySuspects(void)
{
   char str[5];

   lbNoWidth->Items->Clear();  //clear out suspect frames inf

   int inc;

   for (int i=CHAN; i<srecnum; i+=CHANNELS){
      if (sfdata[i]->IsDeleted()) ;
      else {
         if( (sfdata[i]->GetWidth1Val()) ==0){
            sprintf(str,"%d",i/CHANNELS);
			lbNoWidth->Items->Add(str);
         }
      }
   }
}

//---------------------------------------------------------------------------

void __fastcall TForm1::bChangeClick(TObject *Sender)
{
   double AXMin,AXMax,AYMin,AYMax;
   int szXmin,szXmax,szYmin,szYmax;

   if (srecnum==-1)return;

   szXmin=tbXMin->GetTextLen();
   szXmax=tbXMax->GetTextLen();
   szYmin=tbYMin->GetTextLen();
   szYmax=tbYMax->GetTextLen();

   if (szXmin<1) {
	  Application->MessageBox(L"Enter X Min",L"USER ERROR",MB_OK);
      tbXMin->SetFocus();
      return;
   }
   if (szXmax<1) {
	  Application->MessageBox(L"Enter X Max",L"USER ERROR",MB_OK);
      tbXMax->SetFocus();
      return;
   }
   if (szYmin<1) {
	  Application->MessageBox(L"Enter Y Min",L"USER ERROR",MB_OK);
      tbYMin->SetFocus();
      return;
   }
   if (szYmax<1) {
      Application->MessageBox(L"Enter Y Max",L"USER ERROR",MB_OK);
      tbYMax->SetFocus();
      return;
   }

   AnsiString tmp;
   wchar_t *buf=new wchar_t[szXmin+1];  //   char *buf=new char[szXmin+1];
   tbXMin->GetTextBuf(buf,szXmin+1);
   tmp.sprintf("%s",buf);
   AXMin=tmp.ToDouble();   //  AXMin=atof(buf);
   delete [] buf;

   wchar_t *buf2=new wchar_t[szXmax+1];  //char *buf2=new char[szXmax+1];
   tbXMax->GetTextBuf(buf2,szXmax+1);
   tmp.sprintf("%s",buf2);
   AXMax=tmp.ToDouble();   // AXMax=atof(buf2);
   delete [] buf2;

   wchar_t *buf3=new wchar_t[szYmin+1]; //char *buf3=new char[szYmin+1];
   tbYMin->GetTextBuf(buf3,szYmin+1);
   tmp.sprintf("%s",buf3);
   AYMin=tmp.ToDouble();  // AYMin=atof(buf3);
   delete [] buf3;

   wchar_t *buf4=new wchar_t[szYmax+1]; // char *buf4=new char[szYmax+1];
   tbYMax->GetTextBuf(buf4,szYmax+1);
   tmp.sprintf("%s",buf4);
   AYMax=tmp.ToDouble(); // AYMax=atof(buf4);
   delete [] buf4;

   PlotsinchandataFrame(AXMin,AXMax,AYMin,AYMax,1);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::bPrintClick(TObject *Sender)
{
   DBChart1->PrintLandscape();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::bMetaFileClick(TObject *Sender)
{
   TTMetaFileForm *mff = new TTMetaFileForm(DBChart1, this);
   mff->ShowModal();
   delete mff;

}
//---------------------------------------------------------------------------

void __fastcall TForm1::bDeleteFrameClick(TObject *Sender)
{
   if (srecnum==-1)return;
   sfdata[desiredRec]->DeleteFrame();
   DBChart1->Series[0]->Clear();   //clear out the chart, frame has been deleted
   DBChart1->Series[1]->Clear();
   DBChart1->Series[2]->Clear();
   DBChart1->Series[3]->Clear();

   tbPeak1->Clear();  //erase any previous frame's values
   tbWidth1->Clear();
   eWStrt->Clear();
   eWEnd->Clear();

   tbYMin->Clear();
   tbYMax->Clear();
   tbXMin->Clear();
   tbXMax->Clear();

   displaySuspects();   //only display suspects that are not deleted

}
//---------------------------------------------------------------------------

void __fastcall TForm1::bHistogramsClick(TObject *Sender)
{
   double stddev;
   double binWidth;
   double NumBinsK=0; //#bins for pks
   double NumBinsS=0; //#bins for abs subpks
   double NumBinsW=0; //#bins for widths
   double BinWidthH=0;
   double MIN,MAX;

   if(srecnum==0)return;

   float *arrP=new float[srecnum];     //was [NumofCurvePoints]
   float *arrS=new float[srecnum];     //was [NumofCurvePoints]
   float *arrW=new float[srecnum];    //was [NumofCurvePoints]

   for (int i=0; i<srecnum; i++){
      arrP[i]=0;
      arrS[i]=0;
      arrW[i]=0;
   }
   int i=CHAN;   //what ever is selected: channel to Analyze radio box
   int pointcnt=0;

   while (i<srecnum){                 // get arr loaded with only VALID peaks

      if ((sfdata[i]->IsDeleted())==false){
         if((sfdata[i]->GetWidth1Val())>0){
            arrP[pointcnt]=sfdata[i]->GetPeakVal();
            arrS[pointcnt]=sfdata[i]->GetSubPeakVal();
            arrW[pointcnt]=sfdata[i]->GetWidth1Val();
            pointcnt++;
         }
      }
      i+=CHANNELS;

   }
   if(pointcnt<=0)return;
   HistToScreen(pointcnt,arrP, arrS, arrW);

   delete []arrP;
   delete []arrS;
   delete []arrW;

}
//----------------------------------------------------------------------------

void __fastcall TForm1::HistToScreen(int arrsz,float *arrP, float *arrS, float *arrW)
{

   double stddev;
   double binWidth;
   double NumBinsK=0; //#bins for pks
   double NumBinsS=0; //#bins for abs subpks
   double NumBinsW=0; //#bins for widths
   double BinWidthH=0;
   double MIN,MAX;

   double *validarrPtsPk=new double[arrsz];
   for(int m=0; m<arrsz; m++)validarrPtsPk[m]=0;

   for (int m=0; m<arrsz; m++){
	  validarrPtsPk[m]=arrP[m];  //pass ONLY VALID peaks
   }

   stddev=StdDev(validarrPtsPk,arrsz-1);


   MIN=FindMin(validarrPtsPk,arrsz);
   MAX=FindMax(validarrPtsPk,arrsz);
   BinWidthH=3.5*(stddev)/Power((double)arrsz,0.333333);
   NumBinsK=Ceil( ((double)MAX - (double)MIN)/BinWidthH);

   NumBinsK++;

   int *BINS=new int[NumBinsK];                   //these are the bins with the peak data counts
   for (int m=0; m<NumBinsK; m++)BINS[m]=0;

   float *BINVALS=new float[NumBinsK];
   for (int m=0; m<NumBinsK; m++)BINVALS[m]=MIN+(BinWidthH*m);   //values of the bins

   for (int m=0; m<arrsz; m++){
	  for (int bins=0; bins<NumBinsK-1; bins++){
		 if ((validarrPtsPk[m] >= BINVALS[bins])&&(validarrPtsPk[m] < BINVALS[bins+1])){
			BINS[bins]++;
			break;
		 }
	  }
   }
														//absolute value subpeaks
   double *validarrPtsSub=new double[arrsz];
   for (int m=0; m<arrsz; m++)validarrPtsSub[m]=fabs(arrS[m]);

   stddev=StdDev(validarrPtsSub,arrsz-1);

   MIN=FindMin(validarrPtsSub,arrsz);
   MAX=FindMax(validarrPtsSub,arrsz);
   BinWidthH=3.5*(stddev)/Power((double)arrsz,0.333333);
   NumBinsS=Ceil( ((double)MAX - (double)MIN)/BinWidthH);

   NumBinsS++;

   int *BINSS=new int[NumBinsS];                   //these are the bins with the sub data counts
   for (int m=0; m<NumBinsS; m++)BINSS[m]=0;

   float *BINVALSS=new float[NumBinsS];
   for (int m=0; m<NumBinsS; m++)BINVALSS[m]=MIN+(BinWidthH*m);   //values of the bins

   for (int m=0; m<arrsz; m++){
	  for (int bins=0; bins<NumBinsS-1; bins++){
		 if ((validarrPtsSub[m] >= BINVALSS[bins])&&(validarrPtsSub[m] < BINVALSS[bins+1])){
			BINSS[bins]++;
			break;
		 }
	  }
   }

														  //Widths
   double *validarrPtsWid=new double[arrsz];
   for (int m=0; m<arrsz; m++)validarrPtsWid[m]=arrW[m];

   stddev=StdDev(validarrPtsWid,arrsz-1);

   MIN=FindMin(validarrPtsWid,arrsz);
   MAX=FindMax(validarrPtsWid,arrsz);
   BinWidthH=3.5*(stddev)/Power((double)arrsz,0.333333);
   NumBinsW=Ceil( ((double)MAX - (double)MIN)/BinWidthH);

   NumBinsW++;

   int *BINSW=new int[NumBinsW];                   //these are the bins the width data0 counts
   for (int m=0; m<NumBinsW; m++)BINSW[m]=0;

   float *BINVALSW=new float[NumBinsW];           //these are the bins with the width
   for (int m=0; m<NumBinsW; m++)BINVALSW[m]=MIN+(BinWidthH*m);   //values of the bins

   for (int m=0; m<arrsz; m++){
	  for (int bins=0; bins<NumBinsW; bins++){
		 if ((validarrPtsWid[m] >= BINVALSW[bins])&&(validarrPtsWid[m] < BINVALSW[bins+1])){
			BINSW[bins]++;
			break;
		 }
	  }
   }
	printf("");
//   THistogramForm *hist = new THistogramForm(BINS,BINSS,BINSW,NumBinsK,BINVALS,BINVALSS,BINVALSW,this);
   THistogramForm *hist = new THistogramForm(BINS,BINVALS,NumBinsK,BINSS,BINVALSS,NumBinsS,
											 BINSW,BINVALSW,NumBinsW,this);
   hist->ShowModal();

   TfAmpvsDurPlt *adplt = new TfAmpvsDurPlt(arrP,arrS,arrW,arrsz,this);
   adplt->ShowModal();

   delete adplt;
   delete hist;
   delete []BINVALS;
   delete []BINVALSS;
   delete []BINVALSW;
   delete []BINS;
   delete []BINSS;
   delete []BINSW;
}

//----------------------------------------------------------------------------
void __fastcall TForm1::bImportPeaksWidthsClick(TObject *Sender)
{
  FILE *stream;
  char FirstLine[512];
  AnsiString astr;
  float peak,subpeak,width;
  int rec,ch;
  char *token;
  bool ok;
  float *arrP=new float [10000];
  float *arrSP=new float[10000];
  float *arrW=new float[10000];
  int arrCNT=0;


  CHAN=RadioGroup1->ItemIndex;  //reset GLOBAL CHAN::0=chan1,1=chan2,2=chan3,3=chan4
								//this selects user's channel to be analyzed
  if(CHAN<0){
	 CHAN=0;
	 Application->MessageBoxA(L"No CHANNEL selected default to 1",L"WARNING",MB_OK);
  }
  dImportPeaksWidths->Options.Clear();
  dImportPeaksWidths->Options << ofAllowMultiSelect << ofFileMustExist;
  dImportPeaksWidths->Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
  dImportPeaksWidths->FilterIndex = 2; // start the dialog showing all files

  if (dImportPeaksWidths->Execute())
  {
	 for (int i = 0; i < dImportPeaksWidths->Files->Count; i ++){
		stream = fopen(AnsiString(dImportPeaksWidths->Files->Strings[i]).c_str(), "r");
		if (stream){
		   fgets(FirstLine, sizeof(FirstLine), stream);
		   astr=FirstLine;
		   int pos=astr.Pos("REC");
		   if(pos<0){
			  Application->MessageBoxA(L"Bad P/W file format",L"USER_ERR",MB_OK);
			  break;
		   }
		   else{
			   while(!feof(stream)){
				  fgets(FirstLine, sizeof(FirstLine), stream);

				  token=strtok(FirstLine,"\t");
				  astr=token;
				  if(token!=NULL)ok=GetNUM(astr,rec);
				  if(ok){
					 token=strtok(NULL,"\t");
					 astr=token;
					 if(token!=NULL)ok=GetNUM(astr,ch);
					 if(ok && ch==CHAN){      //only do user selected channel
						token=strtok(NULL,"\t");
						astr=token;
						if(token!=NULL)ok=GetNUM(astr,arrP,arrCNT);
						if(ok){
						   token=strtok(NULL,"\t");
						   astr=token;
						   if(token!=NULL)ok=GetNUM(astr,arrSP,arrCNT);
						   if(ok){
							  token=strtok(NULL,"\n");
							  astr=token;
							  if(token!=NULL)ok=GetNUM(astr,arrW,arrCNT);

							  if(ok && arrW[arrCNT]!=0)arrCNT++;
						   }
						}
					 }
				  }
			   }
		   }
		} //end if stream
	 } //end files

  }   //end execute

  HistToScreen(arrCNT,arrP,arrSP, arrW);

  delete [] arrP;
  delete [] arrSP;
  delete [] arrW;
}
//---------------------------------------------------------------------------
bool __fastcall TForm1::GetNUM(AnsiString astr, float *arr, int idx)
{
   bool ok;

   ok=TryStrToFloat(astr,arr[idx]);
   if(!ok){
	  Application->MessageBoxA (L"Bad Float Conversion",L"APP_ERR",MB_OK);
	  return(false);
   }
   else return(true);
}

//---------------------------------------------------------------------------
bool __fastcall TForm1::GetNUM(AnsiString astr, int &intval)
{

	bool ok;
	intval=0;
	ok=TryStrToInt(astr,intval);
	if(!ok){
	   Application->MessageBoxA (L"Bad Int Conversion",L"APP_ERR",MB_OK);
	   return(false);
	}
	else return(true);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::bRankPlotClick(TObject *Sender)
{
   float mxpk,mnpk,mnrank,mxrank;
   float *pkarr=new float[srecnum-1];
   float *rankarr=new float[srecnum-1],pk;
   int RankType=rgRankType->ItemIndex;       //0=all, 1=pos, 2=neg
   char type[4];

   if (RankType==0)sprintf(type,"ALL");
   else if (RankType==1)sprintf(type,"Pos");
   else if (RankType==2)sprintf(type,"Neg");

   NumValidPeaks=0;

   vector<float>::iterator it,it1;

   for(int idx=CHAN+CHANNELS; idx<srecnum; idx+=CHANNELS){

      if (idx>=srecnum)break;

      if ((sfdata[idx]->IsDeleted())==false){           //get valid peaks from all frames of chosen channel
          if ((sfdata[idx]->GetWidth1Val()) > 0) {
             pk=sfdata[idx]->GetPeakVal();
             if (RankType==1){                //pos pks ONLY
                if (pk>0){
                   pkarr[NumValidPeaks]=fabs(pk);
                   NumValidPeaks++;
                }
             }
             else if (RankType==2){           //neg pks ONLY
                if (pk<0){
                   pkarr[NumValidPeaks]=fabs(pk);
                   NumValidPeaks++;
                }
             }
             else {                              //All
                pkarr[NumValidPeaks]=fabs(pk);
                NumValidPeaks++;
             }
          }
      }
   }

   if(NumValidPeaks<=0)return;
   vector<float> v(pkarr[0], NumValidPeaks-1);

  // vector<float> v(pkarr, pkarr+NumValidPeaks-1);
   stable_sort(v.begin(),v.end()) ;                      //sort all of the valid peaks from the file

   int idx=0;
   for (it=v.begin(); it!=v.end(); it++ ){
      pkarr[idx]=*it;
      idx++;
   }
   it=v.begin();
   mnpk=*it;
   it=v.end()-1;
   mxpk=*it;
   for (int m=0; m<NumValidPeaks; m++)rankarr[m]=m/(float)NumValidPeaks;


   vector<float> v1(rankarr, rankarr+NumValidPeaks-1);
   stable_sort(v1.begin(),v1.end());
   it1=v1.begin();
   mnrank=*it1;
   it1=v1.end()-1;
   mxrank=*it1;

   TWeighted *rank= new TWeighted(type,fname,NumValidPeaks,mnpk,mxpk,mnrank,mxrank,pkarr,rankarr,this);
   rank->ShowModal();
   delete []pkarr;
   delete []rankarr;

}

