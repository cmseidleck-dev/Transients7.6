//---------------------------------------------------------------------------

#ifndef HistogramH
#define HistogramH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <VCLTee.Chart.hpp>
#include <VCLTee.DBChart.hpp>
#include <ExtCtrls.hpp>
#include <VCLTee.Series.hpp>
#include <VCLTee.TeEngine.hpp>
#include <VCLTee.TeeProcs.hpp>
#include <Vcl.Dialogs.hpp>
//---------------------------------------------------------------------------
class THistogramForm : public TForm
{
__published:	// IDE-managed Components
        TDBChart *DBChartWidth;
        TBarSeries *Series2;
        TDBChart *DBChartPeak;
        TBarSeries *Series3;
        TButton *bPrint;
	TButton *bMetafile;
	TSaveDialog *dHistSave;
        void __fastcall bPrintClick(TObject *Sender);

	void __fastcall bMetafileClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall THistogramForm(TComponent* Owner);
        virtual __fastcall THistogramForm(int *pkarr, int *subpkarr, int *widtharr, double NumHistBins,
                                         float *BinValsPk,float *BinValsSub,float *BinValsWidth,TComponent* Owner);

        virtual __fastcall THistogramForm(int *pkarr,float *BINVALS,double NumHistBins,
                                          int *subpkarr, float *BINVALSS,double NumHistBinsS,
                                          int *widtharr, float *BINVALSW, double NumHistBinsW,
                                          TComponent* Owner);

};
//---------------------------------------------------------------------------
extern PACKAGE THistogramForm *HistogramForm;
//---------------------------------------------------------------------------
#endif
