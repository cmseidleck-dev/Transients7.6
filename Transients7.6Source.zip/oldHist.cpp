/*   NumHistBins=ceil(sqrt(NumOfCurvePoints));

   float MinPk=0,MaxPk=0,MinSubPk=0,MaxSubPk=0,MinWidth=0,MaxWidth=0;
   float incrPk,incrSubPk,incrWidth;
   float mnpk,mxpk,mxsub,mnsub,mnwidth,mxwidth;


   for(int idx=CHAN+CHANNELS; idx<srecnum; idx+=CHANNELS){

     if (idx>=srecnum)break;

     if ((sfdata[idx]->IsDeleted())==false){
        if ((sfdata[idx]->GetWidth1Val()) > 0) {
           if ((mnpk=sfdata[idx]->GetPeakVal()) < MinPk)MinPk=mnpk;    //find min Peak
        }
     }
     if ((sfdata[idx]->IsDeleted())==false){
        if ((mxpk=sfdata[idx]->GetPeakVal()) > MaxPk)MaxPk=mxpk;
     }
     if ((sfdata[idx]->IsDeleted())==false){
        if ((sfdata[idx]->GetWidth1Val()) > 0) {
           if ((mnsub=sfdata[idx]->GetSubPeakVal()) < MinSubPk)MinSubPk=mnsub;
        }
     }
     if ((sfdata[idx]->IsDeleted())==false) {
        if  ((mxsub=sfdata[idx]->GetSubPeakVal()) > MaxSubPk)MaxSubPk= mxsub;
     }
     if ((sfdata[idx]->IsDeleted())==false) {
        if ((sfdata[idx]->GetWidth1Val()) > 0) {
           if ((mnwidth=sfdata[idx]->GetWidth1Val())< MinWidth)MinWidth=mnwidth;
        }
     }
     if ((sfdata[idx]->IsDeleted())==false) {
        if ((mxwidth=sfdata[idx]->GetWidth1Val())> MaxWidth)MaxWidth=mxwidth;
     }
   }

   incrPk=(fabs(MaxPk-MinPk))/NumHistBins;
   incrSubPk=(fabs(MaxSubPk-MinSubPk))/NumHistBins;
   incrWidth=(fabs(MaxWidth-MinWidth))/NumHistBins;


   int *plotarrPk=new int[NumHistBins];       //these are the incremented histogram bins
   int *plotarrSubPk=new int[NumHistBins];
   int *plotarrWidth=new int[NumHistBins];

   for (int i=0; i<NumHistBins; i++){     //init the bins
      plotarrPk[i]=0;
      plotarrSubPk[i]=0;
      plotarrWidth[i]=0;
   }
   float *BinValsPk=new float[NumHistBins];              //these are the values of the PEAK bins
   float *BinValsSub=new float[NumHistBins];             //these are vals for SUBPK bins
   float *BinValsWidth=new float[NumHistBins];           //thsese are the vals for WIDTH bins

   for (int i=0; i<NumHistBins-1; i++){
      BinValsPk[i]=mnpk+incrPk*(i+1);   //bin vals for Pk
      BinValsSub[i]=mnsub+incrSubPk*(i+1);   //bin vals for SubPk
      BinValsWidth[i]=mnwidth+incrWidth*(i+1);   //bin vals for width
   }
   int i=NumHistBins-1;
   BinValsPk[i]=mxpk;
   BinValsSub[i]=mxsub;
   BinValsWidth[i]=mxwidth;

   for (int i=CHAN+1; i<srecnum; i+=CHANNELS){
      if (i>=srecnum)break;
      if ((sfdata[i]->GetWidth1Val()) > 0) {
         if ((sfdata[i]->IsDeleted())==false) {
            for (int bins=0; bins<NumHistBins; bins++){
               if ((sfdata[i]->GetPeakVal()) <= BinValsPk[bins]) {
                  plotarrPk[bins]++;
                  break;
               }
            }
         }
      }
   }

   for (int i=CHAN+1; i<srecnum; i+=CHANNELS){
      if (i>=srecnum)break;
      if ((sfdata[i]->GetWidth1Val()) > 0) {
         if ((sfdata[i]->IsDeleted())==false) {
            for (int bins=0; bins<NumHistBins; bins++){
               if ((fabs(sfdata[i]->GetSubPeakVal())) <= BinValsSub[bins]) {
                  plotarrSubPk[bins]++;
                  break;
               }
            }
         }
      }
   }

   for (int i=CHAN+1; i<srecnum; i+=CHANNELS){
      if (i>=srecnum)break;
      if ((sfdata[i]->GetWidth1Val()) > 0) {
         if ((sfdata[i]->IsDeleted())==false) {
            for (int bins=0; bins<NumHistBins; bins++){
               if ((sfdata[i]->GetWidth1Val()) <= BinValsWidth[bins]) {
                  plotarrWidth[bins]++;
                  break;
               }
            }
         }
      }
   }
   THistogramForm *hist = new THistogramForm(plotarrPk,plotarrSubPk,plotarrWidth,NumHistBins,
                                             BinValsPk,BinValsSub,BinValsWidth,this);
   hist->ShowModal();
   delete hist;
   delete []BinValsPk;
   delete []BinValsSub;
   delete []BinValsWidth;
   delete []plotarrPk;
   delete []plotarrSubPk;
   delete []plotarrWidth;    */